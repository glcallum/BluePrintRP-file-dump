Config = {}

Config.DrawDistance = 100.0

Config.Pads = {

	{
		Text = 'Press ~INPUT_CONTEXT~ to enter ~y~house~s~.',
		Marker = vector3(1400.6, 1126.6, 113.3),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1400.5, 1129.0, 114.3), h = 0.87 }
	},

	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~y~house~s~.',
		Marker = vector3(1400.4, 1129.6, 113.3),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1400.2, 1123.5, 114.8), h = 180.0 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~SandyShores Hospital~s~.',
		Marker = vector3(1838.97, 3672.91, 33.28),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1841.69, 3670.75, 9.69), h = 188.42 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~y~SandyShores Hospital~s~.',
		Marker = vector3(1841.69, 3670.75, 9.69),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1838.97, 3672.91, 33.28), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~Court House~.',
		Marker = vector3(237.87, -412.83, 47.11),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(236.57, -400.48, -84.94), h = 94.5} 
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~y~Court House~s~.',
		Marker = vector3(236.57, -400.48, -85.94),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(237.87, -412.83, 47.11), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~Vinewood PD~.',
		Marker = vector3(619.84, 17.46, 86.85),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(625.17, -3.12, 44.39), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~y~Vinewood PD~s~.',
		Marker = vector3(625.17, -3.12, 43.39),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(619.84, 17.46, 87.85), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~Hookies Kitchen~.',
		Marker = vector3(-2180.41, 4285.67, 39.71),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-2180.23, 4284.20, 40.71), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~y~Hookies kitchen~s~.',
		Marker = vector3(-2180.23, 4284.20, 39.71),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-2180.41, 4285.67, 40.71), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter ~y~Hookies~.',
		Marker = vector3(-2193.6, 4290.10, 48.17),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-2187.12, 4289.07, 40.72), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave ~y~Hookies~s~.',
		Marker = vector3(-2187.12, 4289.07, 39.72),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-2193.6, 4290.10, 49.17), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter ~y~Bay Bar~.',
		Marker = vector3(-262.44, 6290.77, 30.49),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-264.94, 6291.83, 32.19), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave ~y~Bay Bar~s~.',
		Marker = vector3(-264.94, 6291.83, 31.19),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-262.44, 6290.77, 31.49), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter ~y~Cocaine Processing~.',
		Marker = vector3(1233.28, 1876.88,77.879),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1088.58, -3189.55, -38.99), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave ~y~Cocaine processing~s~.',
		Marker = vector3(1088.58, -3189.55, -39.99),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1233.28, 1876.88,78.879), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter ~y~Bahama Mamas~.',
		Marker = vector3(-1388.74, -586.28, 29.22),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-1387.57, -588.01, 29.32), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave ~y~Bahama Mamas~s~.',
		Marker = vector3(-1387.57, -588.01, 29.32),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-1388.74, -586.28, 29.22), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~Black Army Hideout~.',
		Marker = vector3(-359.09, -1870.98, 19.53),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-1266.87, -2962.93, -49.49), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~r~Black Army Hideout~s~.',
		Marker = vector3(-1266.87, -2962.93, -49.49),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(-359.09, -1870.98, 19.53), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to enter the ~y~Sandy PD~.',
		Marker = vector3(1848.52, 3689.87, 33.27),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1853.98, 3716.23, 0.08), h = 24.6 }
	},
	{
		Text = 'Press ~INPUT_CONTEXT~ to leave the ~r~Sandy PD~s~.',
		Marker = vector3(1853.98, 3716.23, 0.08),
		MarkerSettings = {r = 255, g = 55, b = 55, a = 100, type = 1, x = 1.5, y = 1.5, z = 0.5},
		TeleportPoint = { coords = vector3(1848.52, 3689.87, 33.27), h = 24.6 }
	}
	
}