Locales['fin'] = {
	['gunrange'] = " Ampumarata ",
	['actionMessage'] = "Paina ~INPUT_PICKUP~ avataksesi valikko.",
	['difficulty'] = " Vaikeusaste ",
	['easy'] = " Helppo ",
	['normal'] = " Normaali ",
	['hard'] = " Vaikea ",
	['harder'] = " Vaikeampi ",
	['impossible'] = " Mahdoton ",
	['targets'] = " Taulut ",
	['points'] = " Pisteet ",
	['you_got'] = "Sait ",
	['wait_for_turn'] = "~o~ Odota vuoroasi!",
}
