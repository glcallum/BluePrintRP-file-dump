Locales['en'] = {
	['gunrange'] = " Gunrange ",
	['actionMessage'] = "Press ~INPUT_PICKUP~ to open menu.",
	['difficulty'] = " Difficulty ",
	['easy'] = " Easy ",
	['normal'] = " Normal ",
	['hard'] = " Hard ",
	['harder'] = " Harder ",
	['impossible'] = " Impossible ",
	['targets'] = " Targets ",
	['points'] = " Points ",
	['you_got'] = "You got ",
	['wait_for_turn'] = "~o~ Wait for your turn!",
}
