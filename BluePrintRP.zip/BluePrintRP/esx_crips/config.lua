Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 21
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = {x = 1.5, y = 1.5, z = 1.5}
Config.MarkerColor                = { r = 255, g = 50, b = 200 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.CripStations = {

  Crips = {

    Blip = {
      Pos   = {x = 1272.49, y = -1711.69, z = 54.77},
      Sprite  = 89,
      Display = 4,
      Scale   = 0.7,
      Colour  = 38,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_COMBATPISTOL',     price = 3000 },
      { name = 'WEAPON_ASSAULTSMG',       price = 15000 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 15000 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 10000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 100000 },
      { name = 'WEAPON_APPISTOL',         price = 20000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 15000 },
      { name = 'WEAPON_REVOLVER',         price = 10000 },
      { name = 'WEAPON_MICROSMG',        price = 15000 },

    },


	  AuthorizedVehicles = {

      { name = 'Virgo2',  label = 'Virgo' },
      { name = 'Voodoo',  label = 'Voodoo'},
      { name = 'CHEVELLE1970',  label = '1970 Chevrolet Chevelle SS'},
      { name = 'CORVETTEZR1',  label = '2019 Chevrolet Corvette ZR1'},
      { name = 'Z28',  label = '2015 Chevrolet Camaro Z/28'},
      { name = 'ZL12017',  label = '2017 Chevrolet Camaro ZL1'},

	  },

   Cloakrooms = {
      --{ x = -18.43, y = -1438.56, z = 31.10},
    },

    Armories = {
      { x = 1268.53, y = -1710.26, z = 53.77 },

    },

    Vehicles = {
      {
        Spawner    = { x = 1280.23, y = -1722.59, z = 53.65 },
        SpawnPoint = { x = 1283.56, y = -1729.66, z = 52.81 },
        Heading    = 111.5,

      },

    },
  
  Helicopters = {
      {
        Spawner    = { x = 0, y = 0, z = 17.627 },
        SpawnPoint = { x = 0, y = 0, z = 176.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 1273.64, y = -1733.54, z = 50.9},
      --{ x = -25.32, y = -1427.41, z = 29.75 },
    },

    BossActions = {
      { x = 1272.49, y = -1711.69, z = 53.77 },

    },

  },

}