Locales ['en'] = {
	['judge']              	= 'JUDGE',
	['escape_attempt']     	= 'You can not escape. Your community service has been extended.',
	['remaining_msg']      	= 'You have ~b~%s~s~ more actions to complete before you can finish your service.',
	['comserv_msg']       	= '%s has been sentecned in %s months of community service.',
	['comserv_finished']  	= '%s has finished his community service!'
}
