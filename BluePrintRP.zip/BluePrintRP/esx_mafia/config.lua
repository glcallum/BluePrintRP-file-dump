Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.0, y = 1.0, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = {x = 1.5, y = 1.5, z = 1.5}
Config.MarkerColor                = {r = 50, g = 50, b = 204}
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

  Mafia = {

    Blip = {
      Colour  = 29,
      Pos     = { x = 1400.59, y = 1122.53, z = 114.83 },
      Sprite  = 78,
      Display = 4,
      Scale   = 0.7,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_COMBATPISTOL',     price = 300 },
      { name = 'WEAPON_ASSAULTSMG',       price = 1500 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 1500 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 1000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 100000 },
      { name = 'WEAPON_APPISTOL',         price = 2000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 4500 },
      { name = 'WEAPON_HEAVYSNIPER',      price = 120000 },
      { name = 'WEAPON_REVOLVER',         price = 3400 },
    
    },

	  AuthorizedVehicles = {
      { name = 'cls2015',  label = 'Mercedes CLS 63' },
      { name = 'btype',      label = 'Roosevelt' },
      { name = 'cayenne',   label = 'Porsche cayenne' },
      { name = 'g65amg',   label = 'Mercedes G wagon' },
      { name = 'gmcs',       label = 'GMC Sierra 1500 (pickup)' },
      { name = 'xls2',       label = 'Armoured car' },
      { name = 'hfc250',       label = 'Dirtbike' },
      { name = 'bmws',       label = 'Sportbike' },
	  },

    Cloakrooms = {
      { x = 1396.52, y = 1138.05, z = 113.33},
      { x = -811.83, y = 175.06, z = 75.75},
    },

    Armories = {
      { x = 1397.72, y = 1164.08, z = 113.33 },
      { x = -799.89, y = 177.65, z = 71.83 },
    },

    Vehicles = {
      {
        Spawner    = { x = 1401.65, y = 1115.07, z = 113.84 },
        SpawnPoint = { x = 1393.67, y = 1117.65, z = 113.84 },
        Heading    = 90.0,
      },
      {
        Spawner    = { x = -806.59, y = 184.86, z = 71.35 },
        SpawnPoint = { x = -824.45, y = 181.63, z = 71.68 },
        Heading    = 152.02,
      }

    },

    
  Helicopters = {
      {
        Spawner    = { x = 0, y = 0, z = 172.627 },
        SpawnPoint = { x = 0, y = 0, z = 176.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 1414.93, y = 1116.67, z = 113.5 }, --Madrazo's house
      { x = 1414.83, y = 1120.64, z = 113.5 }, --Madrazo's house
      { x = -806.15, y = 162.54, z = 70.54 }, --Michael's house
      { x = -812.47, y = 187.05, z = 71.47 }, --Michael's house
    },

    BossActions = {
      { x = 1404.59, y = 1144.9, z = 113.33 },
      { x = -803.05, y = 171.89, z = 71.84 },
    },

  },

}
