Config = {}
Config.Marker = {
	Pos   = {x = 459.71774291992, y = -988.81756591797, z = 23.914758682251},
	Size  = {x = 2.0, y = 2.0, z = 1.0},
	Color = {r = 26, g = 55, b = 186},
	Hint = 'Press ~INPUT_PICKUP~ to open the criminal record',
	Type = 27,
}


