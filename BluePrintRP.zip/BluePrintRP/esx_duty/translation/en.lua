Locales['en'] = {
  -- regulars
  	['duty'] = 'Press ~INPUT_CONTEXT~ to ~g~enter~s~ /~r~ exit~s~ duty',
	['onduty'] = 'You went on duty.',
	['offduty'] = 'You went off duty.',
	['notpol'] = 'You are not a policemen.',
	['notamb'] = 'You are not a doctor.',
}
