Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = 452.46, y = -980.14, z = 29.68},
    Size  = { x = 2.0, y = 2.0, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },  
    Type  = 27,
  },

  AmbulanceDuty = {
    Pos = { x = 298.588, y = -599.031, z = 42.292},
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 27,
  },
}

