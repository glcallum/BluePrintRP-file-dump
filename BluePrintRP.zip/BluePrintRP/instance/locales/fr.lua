Locales['fr'] = {
  ['left_instance'] = 'vous avez quitté l\'instance',
  ['invite_expired'] = 'invitation expirée',
  ['press_to_enter'] = 'appuyez sur ~INPUT_CONTEXT~ pour entrer dans l\'instance',
  ['entered_instance'] = 'vous êtes entré dans l\'instance',
  ['entered_into'] = '%s est entré dans l\'instance',
  ['left_out'] = '%s est sorti dans l\'instance',
}
