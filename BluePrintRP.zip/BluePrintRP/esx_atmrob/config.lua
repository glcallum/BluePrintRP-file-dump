Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 2

Banks = {
	["Little Seoul 24/7 ATM #1"] = {
		position = { ['x'] = -717.914, ['y'] = -915.680, ['z'] = 19.768 },
		reward = math.random(1000,7000),
		nameofbank = "Little Seoul 24/7 ATM #1",
		lastrobbed = 0
	},

	["Grove Streer LTD Gasoline ATM #1"] = {
		position = { ['x'] = -57.1805, ['y'] = -1752.00, ['z'] = 29.762 },
		reward = math.random(1000,7000),
		nameofbank = "Grove Street LTD Gasoline ATM #1",
		lastrobbed = 0
	},

	["Grapeseed Main street Clothes Store ATM #1"] = {
		position = { ['x'] = 1686.853, ['y'] = 4815.809, ['z'] = 42.708 },
		reward = math.random(1000,7000),
		nameofbank = "Grapeseed Main street Clothes Store ATM #1",
		lastrobbed = 0
	},

	["Innocense Blvd 24/7 ATM #1"] = {
		position = { ['x'] = 33.232, ['y'] = -1347.849, ['z'] = 29.997 },
		reward = math.random(1000,7000),
		nameofbank = "Innocense Blvd 24/7 ATM #1",
		lastrobbed = 0
	},

	["Morningwood Blvd Morningwood ATM #1"] = {
		position = { ['x'] = -1415.909, ['y'] = -211.825, ['z'] = 46.700 },
		reward = math.random(1000,7000),
		nameofbank = "Morningwood Blvd Morningwood ATM #1",
		lastrobbed = 0
	},

	["Morningwood Blvd Morningwood ATM #2"] = {
		position = { ['x'] = -1430.112, ['y'] = -211.014, ['z'] = 46.700 },
		reward = math.random(1000,7000),
		nameofbank = "Morningwood Blvd Morningwood ATM #2",
		lastrobbed = 0
	},

	["Barberneno Rd 24/7 ATM #1"] = {
		position = { ['x'] = -3240.58, ['y'] = 1008.61, ['z'] = 12.83 },
		reward = math.random(1000,7000),
		nameofbank = "Barberneno Rd 24/7 ATM #1",
		lastrobbed = 0
	},

	["Rockford Drive LTD Gasoline ATM #1"] = {
		position = { ['x'] = -1827.24, ['y'] = 784.89, ['z'] = 138.3 },
		reward = math.random(1000,7000),
		nameofbank = "Rockford Drive LTD Gasoline ATM #1",
		lastrobbed = 0
	},

	["Vinewood Boulevard 24/7 ATM #1"] = {
		position = { ['x'] = 158.6, ['y'] = 234.12, ['z'] = 106.62 },
		reward = math.random(1000,7000),
		nameofbank = "Vinewood Boulevard 24/7 ATM #1",
		lastrobbed = 0
	},

	["Mirror Park Blvd 24/7 ATM #1"] = {
		position = { ['x'] = 1153.884, ['y'] = -326.540, ['z'] = 69.245 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Mirror Park Blvd 24/7 ATM #1",
		lastrobbed = 0
	},

	["Clinton Ave 24/7 ATM #1"] = {
		position = { ['x'] = 381.2827, ['y'] = 323.2518, ['z'] = 103.270 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Clinton Ave 24/7 ATM #1",
		lastrobbed = 0
	},

	["Route 15 24/7 ATM #1"] = {
		position = { ['x'] = 2558.051, ['y'] = 389.4817, ['z'] = 108.660 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Route 15 24/7 ATM #1",
		lastrobbed = 0
	},

	["Route 68 24/7 ATM #1"] = {
		position = { ['x'] = 540.0420, ['y'] = 2671.007, ['z'] = 42.177 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Route 68 24/7 ATM #1",
		lastrobbed = 0
	},

	["Senora Way Dinner ATM #1"] = {
		position = { ['x'] = 2564.399, ['y'] = 2585.100, ['z'] = 38.016 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Senora Way Dinner ATM #1",
		lastrobbed = 0
	},

	["Great Ocean Highway LTD Gasoline ATM #1"] = {
		position = { ['x'] = 1703.138, ['y'] = 6426.783, ['z'] = 32.730 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Great Ocean Highway LTD Gasoline ATM #1",
		lastrobbed = 0
	},

	["Great Ocean Highway 24/7 ATM #1"] = {
		position = { ['x'] = 1735.114, ['y'] = 6411.035, ['z'] = 35.164 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Great Ocean Highway 24/7 ATM #1",
		lastrobbed = 0
	},

	["Grapeseed Ave 24/7 ATM #1"] = {
		position = { ['x'] = 1702.842, ['y'] = 4933.593, ['z'] = 42.051 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Grapeseed Ave 24/7 ATM #1",
		lastrobbed = 0
	},

	["Niland Ave 24/7 ATM #1"] = {
		position = { ['x'] = 1967.333, ['y'] = 3744.293, ['z'] = 32.272 }, -- needs adjusting
		reward = math.random(1000,7000),
		nameofbank = "Niland Ave 24/7 ATM #1",
		lastrobbed = 0
	},
}