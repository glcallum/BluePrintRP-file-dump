Locales['en'] = {

	['robbery_cancelled'] = 'the robbery will be cancelled, you will gain nothing!',
	['robbery_successful'] = 'successful robbery you have gained ~g~$',
	['bank_robbery'] = 'Cash Registers',
	['press_to_rob'] = 'press ~INPUT_CONTEXT~ to rob ~b~',
	['robbery_of'] = 'Cash Register robbery: ',
	['seconds_remaining'] = '~w~ seconds remaning',
	['robbery_cancelled_at'] = '[DISPATCH]:Robbery cancelled at: ',
	['robbery_has_cancelled'] = 'robbery has been cancelled: ',
	['already_robbed'] = 'this store has already been robbed. Please wait: ',
	['seconds'] = 'seconds.',
	['rob_in_prog'] = '[DISPATCH]:Robbery in progress at: ',
	['started_to_rob'] = 'you started to rob ',
	['do_not_move'] = ', do not move away!',
	['alarm_triggered'] = 'the alarm has been triggered',
	['hold_pos'] = 'hold for 2 minute and the money is yours!',
	['robbery_complete'] = 'Robbery complete You got $',
	['robbery_complete_at'] = '[DISPATCH]:Robbery complete at: ',
	['min_two_police'] = 'Number of policemen needed: ',
	['robbery_already'] = 'A robbery is already in progress.',

}
