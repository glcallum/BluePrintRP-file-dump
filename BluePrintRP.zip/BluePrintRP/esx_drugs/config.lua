Config              = {}
Config.MarkerType   = 27
Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 2.5, y = 2.5, z = 1.5}
Config.MarkerColor  = {r = 100, g = 204, b = 100}
Config.ShowBlips   = false  --markers visible on the map? (false to hide the markers on the map)

Config.RequiredCopsCoke  = 0
Config.RequiredCopsMeth  = 0
Config.RequiredCopsWeed  = 0
Config.RequiredCopsOpium = 0

Config.TimeToFarm    = 17 * 30
Config.TimeToProcess = 46 * 120
Config.TimeToSell    = 5  * 30

Config.Locale = 'en'

Config.Zones = {
	CokeField =			{x = 1240.68,	y = -3053.93,	z = 13.20,	name = _U('coke_field'),		sprite = 403,	color = 40}, -- done
	CokeProcessing =	{x = -2173.46,	y = 4280.56,	z = 39.6,	name = _U('coke_processing'),	sprite = 402,	color = 40}, -- done
	CokeDealer =		{x = -468.29, 	y = 5357.2, 	z = 79.70,	name = _U('coke_dealer'),		sprite = 403,	color = 75},
	MethField =			{x = 2329.97,   y = 2572.42,    z = 45.50,	name = _U('meth_field'),		sprite = 403,	color = 26}, -- done
	MethProcessing =	{x = 1443.33,   y = 6332.39,    z = 22.80,	name = _U('meth_processing'),	sprite = 403,	color = 26}, -- done
	MethDealer =		{x = 1655.03, 	y = 4874.25, 	z = 41.00,	name = _U('meth_dealer'),		sprite = 403,	color = 75},
	WeedField =			{x = 1427.48,	y = 4319.89,	z = 33.45,	name = _U('weed_field'),		sprite = 140,	color = 52}, -- done
	WeedProcessing =	{x = 423.5,     y = 6472.4,     z = 34.80,	name = _U('weed_processing'),	sprite = 140,	color = 52}, -- done 
	WeedDealer =		{x = -224.34, 	y = -1674.44, 	z = 33.40,	name = _U('weed_dealer'),		sprite = 140,	color = 75},
	OpiumField =		{x = 21.88,	    y = -2664.79,	z = 8.70,	name = _U('opium_field'),		sprite = 51,	color = 60}, -- done
	OpiumProcessing =	{x = 1388.72,	y = 3604.97,	z = 37.90,	name = _U('opium_processing'),	sprite = 51,	color = 60},  -- done
	OpiumDealer =		{x = -179.21, 	y = 6153.64, 	z = 30.0,	name = _U('opium_dealer'),		sprite = 51,	color = 75}
	--OpiumProcessing2 =	{x = 230.55, 	y = -867.68, 	z = 30.29,	name = _U('opium_processing2'),	sprite = 51,	color = 60}
}


-- 1277.46, y = -1732.58, z = 52.35