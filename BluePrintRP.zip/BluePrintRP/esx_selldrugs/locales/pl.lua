Locales ['pl'] = {
	['input'] = 'Kliknij ~INPUT_PICKUP~ aby oferować dragi',
	['reject'] = 'Osoba ~r~odrzuciła~s~ twoją ofertę',
	['no_more_drugs'] = '~r~Nie posiadasz~s~ więcej ~g~dragów!',
	['too_far_away'] = 'Oddaliłeś się! Sprzedawanie ~r~anulowane',
	['remained'] = 'Pozostało ~b~ ',
	['you_have_sold'] = 'Sprzedałeś ',
	['must_be'] = 'Musi być minimalnie~b~ ',
	['too_far_away_from_city'] = 'Jesteś ~r~za daleko~w~ miasta,  tutaj nikt nie kupuje ~g~dragow!',
	['to_sell_drugs'] = ' ~w~policjantów aby sprzedawać ~g~dragi!',
	['weed_pooch'] = ' paczek ~g~marichuany~s~ za~r~ ',
	['meth_pooch'] = ' paczek ~g~metamfetaminy~s~ za~r~ ',
	['coke_pooch'] = ' paczek ~g~kokainy~s~ za~r~ ',
	['opium_pooch'] = ' paczek ~g~opium~s~ za~r~ ',
	['weed'] = ' ~g~marichuany~s~ za~r~ ',
	['meth'] = ' ~g~metamfetaminy~s~ za~r~ ',
	['coke'] = ' ~g~kokainy~s~ za~r~ ',
	['opium'] = ' ~g~opium~s~ za~r~ ',
}