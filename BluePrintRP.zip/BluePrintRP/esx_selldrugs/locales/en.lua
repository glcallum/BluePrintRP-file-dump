Locales ['en'] = {
	['input'] = 'Press ~INPUT_PICKUP~ to offer drugs',
	['reject'] = 'Person rejected your offer and now calling the cops',
	['no_more_drugs'] = 'You dont have more drugs!',
	['too_far_away'] = 'You are too far away! Selling canceled',
	['remained'] = 'Selling drugs please wait ',
	['you_have_sold'] = 'You have sold',
	['must_be'] = 'There must be at least ',
	['too_far_away_from_city'] = 'You are too far away from the city!',
	['to_sell_drugs'] = ' cops to sell drugs!',
	['weed_pooch'] = ' pooch of ~g~weed~s~ for~r~ ',
	['meth_pooch'] = ' pooch of ~g~meth~s~ for~r~ ',
	['coke_pooch'] = ' pooch of ~g~coke~s~ for~r~ ',
	['opium_pooch'] = ' pooch of ~g~opium~s~ for~r~ ',
	['weed'] = ' ~g~weed~s~ for~r~ ',
	['meth'] = ' ~g~meth~s~ for~r~ ',
	['coke'] = ' ~g~coke~s~ for~r~ ',
	['opium'] = ' ~g~opium~s~ for~r~ ',
}