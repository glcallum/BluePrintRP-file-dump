Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 1

Banks = {
	["Little Seoul 24/7 Register #1"] = {
		position = { ['x'] = -706.03717041016, ['y'] = -915.42755126953, ['z'] = 19.215593338013 },
		reward = math.random(500,3000),
		nameofbank = "Little Seoul 24/7 Register #1",
		lastrobbed = 0
	},
	["Little Seoul 24/7 Register #2"] = {
		position = { ['x'] = -706.0966796875, ['y'] = -913.49053955078, ['z'] = 19.215593338013 },
		reward = math.random(500,3000),
		nameofbank = "Little Seoul 24/7 Register #2",
		lastrobbed = 0
	},
	["Innocence Blvd 24/7 Register #1"] = {
		position = { ['x'] = 24.487377166748, ['y'] = -1347.4102783203, ['z'] = 29.497039794922 }, 
		reward = math.random(500,3000),
		nameofbank = "Innocence Blvd 24/7 Register #1",
		lastrobbed = 0
	},
	["Innocence Blvd 24/7 Register #2"] = {
		position = { ['x'] = 24.396217346191, ['y'] = -1344.9005126953, ['z'] = 29.497039794922 },
		reward = math.random(500,3000),
		nameofbank = "Innocence Blvd 24/7 Register #2",
		lastrobbed = 0
	},
	["Mirror Park 24/7 Register #1"] = {
		position = { ['x'] = 1165.0561523438, ['y'] = -324.41815185547, ['z'] = 69.205062866211 }, 
		reward = math.random(500,3000),
		nameofbank = "Mirror Park 24/7 Register #1",
		lastrobbed = 0
	},
	["Mirror Park 24/7 Register #2"] = {
		position = { ['x'] = 1164.6981201172, ['y']= -322.61318969727, ['z'] = 69.205062866211 },
		reward = math.random(500,3000),
		nameofbank = "Mirror Park 24/7 Register #2",
		lastrobbed = 0
	},
	["Downtown Vinewood 24/7 Register #1"] = {
		position = { ['x'] = 372.47518920898, ['y'] = 326.35989379883, ['z'] = 103.56636810303 },
		reward = math.random(500,3000),
		nameofbank = "Downtown Vinewood 24/7 Register #1",
		lastrobbed = 0
	},
	["Downtown Vinewood 24/7 Register #2"] = {
		position = { ['x'] = 373.0817565918, ['y'] = 328.75726318359, ['z'] = 103.56636810303 },
		reward = math.random(500,3000),
		nameofbank = "Downtown Vinewood 24/7 Register #2",
		lastrobbed = 0
	},
	["Rockford Dr 24/7 Register #1"] = {
		position = { ['x'] = -1818.8961181641, ['y'] = 792.91729736328, ['z'] = 138.08184814453 },
		reward = math.random(500,3000),
		nameofbank = "Rockford Dr 24/7 Register #1",
		lastrobbed = 0
	},
	["Rockford Dr 24/7 Register #2"] = {
		position = { ['x'] = -1820.2630615234, ['y'] = 794.45971679688, ['z'] = 138.0887298584 }, 
		reward = math.random(500,3000),
		nameofbank = "Rockford Dr 24/7 Register #2",
		lastrobbed = 0
	},
	["Route 68 24/7 Register #1"] = {
		position = { ['x'] = 549.36108398438, ['y'] = 2669.0007324219, ['z'] = 42.156490325928 },
		reward = math.random(500,3000),
		nameofbank = "Route 68 24/7 Register #1",
		lastrobbed = 0
	},
	["Route 68 24/7 Register #2"] = {
		position = { ['x'] = 549.05975341797, ['y'] = 2671.443359375, ['z'] = 42.156490325928 }, 
		reward = math.random(500,3000),
		nameofbank = "Route 68 24/7 Register #2",
		lastrobbed = 0
	},
	["South Senora Fwy 24/7 Register #1"] = {
		position = { ['x'] = 2677.9641113281, ['y'] = 3279.4440917969, ['z'] = 55.241130828857 },
		reward = math.random(500,3000),
		nameofbank = "South Senora Fwy 24/7 Register #1",
		lastrobbed = 0
	},
	["South Senora Fwy 24/7 Register #2"] = {
		position = { ['x'] = 2675.8774414063, ['y'] = 3280.537109375, ['z'] = 55.241130828857 },
		reward = math.random(500,3000),
		nameofbank = "South Senora Fwy 24/7 Register #2",
		lastrobbed = 0
	},
	["North Senora Fwy 24/7 Register #1"] = {
		position = { ['x'] = 1727.8493652344, ['y'] = 6415.2983398438, ['z'] = 35.037227630615 },
		reward = math.random(500,3000),
		nameofbank = "North Senora Fwy 24/7 Register #1",
		lastrobbed = 0
	},
	["North Senora Fwy 24/7 Register #2"] = {
		position = {  ['x'] = 1728.8804931641, ['y'] = 6417.4360351563, ['z'] = 35.037227630615 },
		reward = math.random(500,3000),
		nameofbank = "North Senora Fwy 24/7 Register #2",
		lastrobbed = 0
	},
	["Great Ocean Hwy 24/7 Register #1"] = {
		position = { ['x'] = 372.47518920898, ['y'] = 326.35989379883, ['z'] =103.56636810303 }, 
		reward = math.random(500,3000),
		nameofbank = "Great Ocean Hwy 24/7 Register #1",
		lastrobbed = 0
	},
	["Great Ocean Hwy 24/7 Register #2"] = {
		position = { ['x'] = 373.0817565918, ['y'] = 328.75726318359, ['z'] = 103.56636810303 },
		reward = math.random(500,3000),
		nameofbank = "Great Ocean Hwy 24/7 Register #2",
		lastrobbed = 0
	},
	["Algonquin 24/7 Register"] = {
		position = { ['x'] = 1392.8726806641, ['y'] = 3606.3913574219, ['z'] = 34.98091506958 }, 
		reward = math.random(500,3000),
		nameofbank = "Algonquin 24/7 Register",
		lastrobbed = 0
	},

	["Route 68 Liquor Store Register"] = {
		position = { ['x'] = 1165.9134521484, ['y'] = 2710.7854003906, ['z'] = 38.157711029053 }, 
		reward = math.random(500,3000),
		nameofbank = "Route 68 Liquor Store Register",
		lastrobbed = 0
	},

	["El Rancho Blvd Liquor Store Register"] = {
		position = { ['x'] = 1134.2418212891, ['y'] = -982.54541015625, ['z'] = 46.41584777832 }, 
		reward = math.random(500,3000),
		nameofbank = "El Rancho Blvd Liquor Store Register",
		lastrobbed = 0
	},

	["Prosperity Liquor Store Register"] = {
		position = { ['x'] = -1486.2586669922, ['y'] = -377.96697998047, ['z'] = 40.163429260254 }, 
		reward = math.random(500,3000),
		nameofbank = "Prosperity Liquor Store Register",
		lastrobbed = 0
	},

	["Great Ocean Hwy Liquor Store Register"] = {
		position = { ['x'] = 2966.4309082031, ['y'] = 390.98095703125, ['z'] = 15.043313980103 },
		reward = math.random(500,3000),
		nameofbank = "Great Ocean Hwy Liquor Store Register",
		lastrobbed = 0
	},

	["Pacific Standard Bank Booth #1"] = {
		position = { ['x'] = 242.81385803223, ['y'] = 226.59515380859, ['z'] = 106.28727722168 }, 
		reward = math.random(500,3000),
		nameofbank = "Pacific Standard Bank Booth #1",
		lastrobbed = 0
	},

	["Pacific Standard Bank Booth #2"] = {
		position = { ['x'] = 247.9873046875, ['y'] = 224.75602722168, ['z'] = 106.28736877441 }, 
		reward = math.random(500,3000),
		nameofbank = "Pacific Standard Bank Booth #2",
		lastrobbed = 0
	},

	["Pacific Standard Bank Booth #3"] = {
		position = { ['x'] = 252.95489501953, ['y'] = 222.85342407227, ['z'] = 106.28684234619 }, 
		reward = math.random(500,3000),
		nameofbank = "Pacific Standard Bank Booth #3",
		lastrobbed = 0
	}
}
