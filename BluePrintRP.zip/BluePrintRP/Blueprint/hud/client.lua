local hudStatus = true
local thirst = 100
local hunger = 100
local health = 100
local armor = 100
local voipLevel = 50
local myStamina = 0
local usingSeatbelt = false
local isTalking = false
local myOxygen = false

local hour = 0
local minute = 0

DecorRegister('voipRange', 3)
DecorSetInt(GetPlayerPed(-1), 'voipRange', 2)

Citizen.CreateThread(function()
 while true do
  Citizen.Wait(100)
  local currentVOIP = DecorGetInt(PlayerPedId(), 'voipRange')
  if currentVOIP ~= nil then
   if currentVOIP >= 1 then
    voipLevel = 33.3*currentVOIP
   end
  end
 end
end)

-- Hud Bars
Citizen.CreateThread(function()
 while true do
  Citizen.Wait(5)
  if hudStatus then
   -- Background
   DrawRect(0.0853, 0.9800, 0.1430, 0.025, 81, 81, 84, 255)
   -- Health
   DrawRect(0.0148 + (0.07)/2, 0.9740, 0.07, 0.008595, 188,188,188,80)
   if health >= 0 then
    DrawRect(0.0148 + (health/1428.52142857)/2, 0.9740, health/1428.52142857, 0.008595, 55,185,55,177)
   end
   -- Armour

   DrawRect(0.0865 + (0.069)/2,  0.9740, 0.069, 0.008595, 188,188,188,80)

   if IsPedSwimmingUnderWater(PlayerPedId()) then
    if myOxygen >= 0.0 then
     DrawRect(0.0865 + (myOxygen/1449.22536232)/2, 0.9740, myOxygen/1449.22536232, 0.008595, 115,115,255,177)
    end
   else
    DrawRect(0.0865 + (armor/1449.22536232)/2, 0.9740, armor/1449.22536232, 0.008595, 115,115,255,177)
   end

    -- Thrist
   --DrawRect(0.0506 + (0.034)/2, 0.9860, 0.034, 0.008595, 188,188,188,80)
   DrawRect(0.0506 + (0.034)/2, 0.9860, 0.035, 0.008595, 188,188,188,80)
   --DrawRect(0.0506 + (thirst/2898.50072464)/2, 0.9860, thirst/2898.50072464, 0.008595, 75,75,255,177)
   DrawRect(0.0506 + (thirst/2898.50072464)/2, 0.9860, thirst/2898.50072464, 0.008595, 75,75,255,177)
   -- Hunger
   --DrawRect(0.0148 + (0.035)/2, 0.9860, 0.035, 0.008595, 188,188,188,80)
   DrawRect(0.0148 + (0.035)/2, 0.9860, 0.035, 0.008595, 188,188,188,80)
   --DrawRect(0.0148 + (hunger/2857.09285714)/2, 0.9860, hunger/2857.09285714, 0.008595, 55,185,55,177)
   DrawRect(0.0148 + (hunger/2857.09285714)/2, 0.9860, hunger/2857.09285714, 0.008595, 55,185,55,177)

   -- VOIP
   DrawRect(0.0863 + (0.035)/2, 0.9860, 0.035, 0.008595, 188,188,188,80)
   DrawRect(0.0863 + (voipLevel/2857.22536232)/2, 0.9860, voipLevel/2857.22536232, 0.008595, 205,205,205,155)

   -- Talking
   if isTalking then
    DrawRect(0.0863 + (100/2857.22536232)/2, 0.9860, 100/2857.22536232, 0.008595, 255, 55, 155,155)
   end

   DrawRect(0.1218 + (0.034)/2, 0.9860, 0.034, 0.008595, 188,188,188,80)
   DrawRect(0.1218 + (myStamina/2857.22536232)/2, 0.9860, myStamina/2857.22536232, 0.008595, 255,255,55,80)
  else
   Citizen.Wait(500)
  end
 end
end)

Citizen.CreateThread(function()
 while true do
  Citizen.Wait(100)
  hudStatus = true
  if hudStatus then
   CalculateTimeToDisplay()
   health = GetEntityHealth(PlayerPedId())-100
   armor = GetPedArmour(PlayerPedId())
   isTalking = NetworkIsPlayerTalking(PlayerId())
   myStamina = 100-GetPlayerSprintStaminaRemaining(PlayerId())-3
   myOxygen = GetPlayerUnderwaterTimeRemaining(PlayerId())*10-3
  end
 end
end)

Citizen.CreateThread(function()
 while true do
  Citizen.Wait(1000)
   TriggerEvent('esx_status:getStatus', 'hunger', function(status)
    if status.val >= 1000000 then
     hunger = 100
    else
     hunger = status.val/10000
    end
   end)

   TriggerEvent('esx_status:getStatus', 'thirst', function(status)
    if status.val >= 1000000 then
     thirst = 100
    else
     thirst = status.val/10000
    end
   end)
 end
end)





local zoneNames = {
 AIRP = "Los Santos International Airport",
 ALAMO = "Alamo Sea",
 ALTA = "Alta",
 ARMYB = "Fort Zancudo",
 BANHAMC = "Banham Canyon Dr",
 BANNING = "Banning",
 BAYTRE = "Baytree Canyon",
 BEACH = "Vespucci Beach",
 BHAMCA = "Banham Canyon",
 BRADP = "Braddock Pass",
 BRADT = "Braddock Tunnel",
 BURTON = "Burton",
 CALAFB = "Calafia Bridge",
 CANNY = "Raton Canyon",
 CCREAK = "Cassidy Creek",
 CHAMH = "Chamberlain Hills",
 CHIL = "Vinewood Hills",
 CHU = "Chumash",
 CMSW = "Chiliad Mountain State Wilderness",
 CYPRE = "Cypress Flats",
 DAVIS = "Davis",
 DELBE = "Del Perro Beach",
 DELPE = "Del Perro",
 DELSOL = "La Puerta",
 DESRT = "Grand Senora Desert",
 DOWNT = "Downtown",
 DTVINE = "Downtown Vinewood",
 EAST_V = "East Vinewood",
 EBURO = "El Burro Heights",
 ELGORL = "El Gordo Lighthouse",
 ELYSIAN = "Elysian Island",
 GALFISH = "Galilee",
 GALLI = "Galileo Park",
 golf = "GWC and Golfing Society",
 GRAPES = "Grapeseed",
 GREATC = "Great Chaparral",
 HARMO = "Harmony",
 HAWICK = "Hawick",
 HORS = "Vinewood Racetrack",
 HUMLAB = "Humane Labs and Research",
 JAIL = "Bolingbroke Penitentiary",
 KOREAT = "Little Seoul",
 LACT = "Land Act Reservoir",
 LAGO = "Lago Zancudo",
 LDAM = "Land Act Dam",
 LEGSQU = "Legion Square",
 LMESA = "La Mesa",
 LOSPUER = "La Puerta",
 MIRR = "Mirror Park",
 MORN = "Morningwood",
 MOVIE = "Richards Majestic",
 MTCHIL = "Mount Chiliad",
 MTGORDO = "Mount Gordo",
 MTJOSE = "Mount Josiah",
 MURRI = "Murrieta Heights",
 NCHU = "North Chumash",
 NOOSE = "N.O.O.S.E",
 OCEANA = "Pacific Ocean",
 PALCOV = "Paleto Cove",
 PALETO = "Paleto Bay",
 PALFOR = "Paleto Forest",
 PALHIGH = "Palomino Highlands",
 PALMPOW = "Palmer-Taylor Power Station",
 PBLUFF = "Pacific Bluffs",
 PBOX = "Pillbox Hill",
 PROCOB = "Procopio Beach",
 RANCHO = "Rancho",
 RGLEN = "Richman Glen",
 RICHM = "Richman",
 ROCKF = "Rockford Hills",
 RTRAK = "Redwood Lights Track",
 SanAnd = "San Andreas",
 SANCHIA = "San Chianski Mountain Range",
 SANDY = "Sandy Shores",
 SKID = "Mission Row",
 SLAB = "Stab City",
 STAD = "Maze Bank Arena",
 STRAW = "Strawberry",
 TATAMO = "Tataviam Mountains",
 TERMINA = "Terminal",
 TEXTI = "Textile City",
 TONGVAH = "Tongva Hills",
 TONGVAV = "Tongva Valley",
 VCANA = "Vespucci Canals",
 VESP = "Vespucci",
 VINE = "Vinewood",
 WINDF = "Ron Alternates Wind Farm",
 WVINE = "West Vinewood",
 ZANCUDO = "Zancudo River",
 ZP_ORT = "Port of South Los Santos",
 ZQ_UAR = "Davis Quartz"
}

local showCompass = true
local lastStreet = nil
local lastStreetName = ""
local zone = "Unknown";

function getCardinalDirectionFromHeading(heading)
    if heading >= 315 or heading < 45 then
        return "North Bound"
    elseif heading >= 45 and heading < 135 then
        return "West Bound"
    elseif heading >=135 and heading < 225 then
        return "South Bound"
    elseif heading >= 225 and heading < 315 then
        return "East Bound"
    end
end

Citizen.CreateThread(function()
    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), true))
    local currentStreetHash, intersectStreetHash = GetStreetNameAtCoord(x, y, z, currentStreetHash, intersectStreetHash)
    currentStreetName = GetStreetNameFromHashKey(currentStreetHash)
    intersectStreetName = GetStreetNameFromHashKey(intersectStreetHash)
    zone = tostring(GetNameOfZone(x, y, z))
    playerStreetsLocation = zoneNames[tostring(zone)]

    if not zone then
        zone = "UNKNOWN"
        zoneNames['UNKNOWN'] = zone
    elseif not zoneNames[tostring(zone)] then
        local undefinedZone = zone .. " " .. x .. " " .. y .. " " .. z
        zoneNames[tostring(zone)] = "Undefined Zone"
    end

    if intersectStreetName ~= nil and intersectStreetName ~= "" then
        playerStreetsLocation = currentStreetName .. " | " .. intersectStreetName .. " | " .. zoneNames[tostring(zone)]
    elseif currentStreetName ~= nil and currentStreetName ~= "" then
        playerStreetsLocation = currentStreetName .. " | " .. zoneNames[tostring(zone)]
    else
        playerStreetsLocation = zoneNames[tostring(zone)]
    end

    while true do
        Citizen.Wait(2000)

            local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), true))
            local currentStreetHash, intersectStreetHash = GetStreetNameAtCoord(x, y, z, currentStreetHash, intersectStreetHash)
            currentStreetName = GetStreetNameFromHashKey(currentStreetHash)
            intersectStreetName = GetStreetNameFromHashKey(intersectStreetHash)
            zone = tostring(GetNameOfZone(x, y, z))
            playerStreetsLocation = zoneNames[tostring(zone)]

            if not zone then
                zone = "UNKNOWN"
                zoneNames['UNKNOWN'] = zone
            elseif not zoneNames[tostring(zone)] then
                local undefinedZone = zone .. " " .. x .. " " .. y .. " " .. z
                zoneNames[tostring(zone)] = "Undefined Zone"
            end

            if intersectStreetName ~= nil and intersectStreetName ~= "" then
                playerStreetsLocation = currentStreetName .. " | " .. intersectStreetName .. " | " .. zoneNames[tostring(zone)]
            elseif currentStreetName ~= nil and currentStreetName ~= "" then
                playerStreetsLocation = currentStreetName .. " | " .. zoneNames[tostring(zone)]
            else
                playerStreetsLocation = zoneNames[tostring(zone)]
            end

  end
end)


Citizen.CreateThread(function()

    while true do
        Citizen.Wait(1)
        if IsPedInAnyVehicle(PlayerPedId(), false) then

        local Mph = GetEntitySpeed(GetVehiclePedIsIn(GetPlayerPed(-1), false)) * 2.236936
        local fuel = GetVehicleFuelLevel(GetVehiclePedIsIn(GetPlayerPed(-1), false))


        drawTxt(0.667, 1.424, 1.0,1.0,0.55 , "~w~" .. math.ceil(Mph), 255, 255, 255, 200)  -- INT: kmh
        drawTxt(0.685, 1.432, 1.0,1.0,0.3, "~w~ mp/h", 255, 255, 255, 200)  -- TXT: kmh

        drawTxt(0.714, 1.424, 1.0,1.0,0.55 , "~w~" .. math.ceil(fuel), 255, 255, 255, 200)  -- INT: kmh
        drawTxt(0.732, 1.432, 1.0,1.0,0.3, "~w~ Fuel", 255, 255, 255, 200)  -- TXT: kmh

        if usingSeatbelt then
          DisableControlAction(0, 75)
          drawTxt(0.757, 1.429, 1.0,1.0,0.4 , "~g~ BELT", 255, 255, 255, 200)  -- INT: kmh
        else
          drawTxt(0.757, 1.429, 1.0,1.0,0.4, "~r~ BELT", 255, 255, 255, 200)  -- TXT: kmh
        end

          drawTxt(0.668, 1.395, 1.0,1.0,0.33 ,"" .. hour .. ":" .. minute, 255, 255, 255, 200)

          SetTextFont(4)
          SetTextProportional(1)
          SetTextScale(0.0, 0.43)
          SetTextColour(255, 255, 255, 200)
          SetTextDropshadow(0, 0, 0, 0, 200)
          SetTextEdge(1, 0, 0, 0, 200)
          SetTextDropShadow()
          SetTextOutline()
          SetTextEntry("STRING")

          if showCompass then
            compass = getCardinalDirectionFromHeading(math.floor(GetEntityHeading(GetPlayerPed(-1)) + 0.5))
            lastStreetName = compass .. " | " .. playerStreetsLocation
          end

          AddTextComponentString(lastStreetName)
          DrawText(0.168, 0.964)
      else
       Citizen.Wait(2000)
      end
  end
end)

function drawTxt(x,y ,width,height,scale, text, r,g,b,a)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end



function CalculateTimeToDisplay()
  hour = GetClockHours()
  minute = GetClockMinutes()
  local type = 'AM'

 if hour == 1 or hour == 2 or hour == 3 or hour == 4 or hour == 5 or hour == 6 or hour == 7 or hour == 8 or hour == 9 or hour == 10 or hour == 11 or hour == 0 then
  type = 'AM'
 else
  type = 'PM'
 end

 if hour <= 9 then
  hour = "0" .. hour
 end
 if minute <= 9 then
  minute = "0" .. minute
 end
 minute = minute..' '..type
end




--========================================================================================--
--==================================== Seat Belt =========================================--
--========================================================================================--
local speedBuffer  = {}
local velBuffer    = {}
local wasInCar     = false
local carspeed = 0
local speed = 0

Citizen.CreateThread(function()
 Citizen.Wait(500)
  while true do
   local ped = GetPlayerPed(-1)
   local car = GetVehiclePedIsIn(ped)
   if car ~= 0 and (wasInCar or IsCar(car)) then
    wasInCar = true
    speedBuffer[2] = speedBuffer[1]
    speedBuffer[1] = GetEntitySpeed(car)
    if speedBuffer[2] ~= nil and GetEntitySpeedVector(car, true).y > 1.0 and speedBuffer[2] > 18.00 and (speedBuffer[2] - speedBuffer[1]) > (speedBuffer[2] * 0.465) and usingSeatbelt == false then
    local co = GetEntityCoords(ped, true)
    local fw = Fwv(ped)
    SetEntityCoords(ped, co.x + fw.x, co.y + fw.y, co.z - 0.47, true, true, true)
    SetEntityVelocity(ped, velBuffer[2].x-10/2, velBuffer[2].y-10/2, velBuffer[2].z-10/4)
    Citizen.Wait(1)
    SetPedToRagdoll(ped, 1000, 1000, 0, 0, 0, 0)
   end
    velBuffer[2] = velBuffer[1]
    velBuffer[1] = GetEntityVelocity(car)

    if IsControlJustPressed(0, 29) then
      if usingSeatbelt == false then
       usingSeatbelt = true
       TriggerEvent('notification', 'Seatbelt Enabled')
      else
       usingSeatbelt = false
       TriggerEvent('notification', 'Seatbelt Disabled', 2)
      end
    end


   elseif wasInCar then
    wasInCar = false
    usingSeatbelt = false
    speedBuffer[1], speedBuffer[2] = 0.0, 0.0
   end
   Citizen.Wait(5)
   speed = math.floor(GetEntitySpeed(GetVehiclePedIsIn(GetPlayerPed(-1), false)) * 2.236936)
  end
end)

function IsCar(veh)
 local vc = GetVehicleClass(veh)
 return (vc >= 0 and vc <= 7) or (vc >= 9 and vc <= 12) or (vc >= 17 and vc <= 20)
end

function Fwv(entity)
 local hr = GetEntityHeading(entity) + 90.0
 if hr < 0.0 then hr = 360.0 + hr end
 hr = hr * 0.0174533
 return { x = math.cos(hr) * 2.0, y = math.sin(hr) * 2.0 }
end

