-- Change 'false' to 'true' to toggle the engine automatically on when entering a vehicle
OnAtEnter = false

-- Change 'false' to 'true' to use a key instead of a button
UseKey = true

if UseKey then
	-- Change this to change the key to toggle the engine (Other Keys at wiki.fivem.net/wiki/Controls)
	ToggleKey = 311
end

