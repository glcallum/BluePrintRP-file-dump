local basespots = {
  {pos = {x = 501.689, y = 5597.961, z = 796.051}}
}
local blockpress = false
local baseblips = {}

RegisterNetEvent("bms:basejumping:rentparachute")
AddEventHandler("bms:basejumping:rentparachute", function(data)
  if (data) then
    local success = data.success

    if (success) then
      local ped = GetPlayerPed(-1)

      GiveWeaponToPed(ped, GetHashKey("gadget_parachute"), 1, 0, false)
      exports.pnotify:SendNotification({text = "You have rented a parachute.  Press <font color='skyblue'>Primary-Attack</font> to deploy it once you have jumped."})
    else
      local msg = data.msg

      exports.pnotify:SendNotification({text = msg})
    end
  end

  blockpress = false
end)

Citizen.CreateThread(function()
  while true do
    Wait(1)

    local ped = GetPlayerPed(-1)
    local pos = GetEntityCoords(ped)
    
    if (#baseblips == 0) then
      for _,v in pairs(basespots) do
        local blip = AddBlipForCoord(v.pos.x, v.pos.y, v.pos.z)

        SetBlipSprite(blip, 94)
        SetBlipScale(blip, 0.85)
        SetBlipColour(blip, 3)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Base Jumping")
        EndTextCommandSetBlipName(blip)

        table.insert(baseblips, blip)
      end
    end

    for _,v in pairs(basespots) do
      DrawMarker(1, v.pos.x, v.pos.y, v.pos.z - 1.0001, 0, 0, 0, 0, 0, 0, 1.2, 1.2, 1.1, 0, 255, 0, 160, 0, 0, 0, 0, 0, 0, 0)

      local dist = Vdist(pos.x, pos.y, pos.z, v.pos.x, v.pos.y, v.pos.z)

      if (dist < 1.2) then
        drawScreenText("Press ~b~E~w~ to rent a parachute.  This will cost $1000")

        if (not blockpress) then
          if (IsControlJustReleased(1, 38) or IsDisabledControlJustReleased(1, 38)) then
            blockpress = true
            TriggerServerEvent("bms:basejumping:rentparachute")
          end
        end
      end
    end
  end
end)