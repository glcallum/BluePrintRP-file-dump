local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}

local GUI = {} -- don't touch
ESX = nil -- don't touch
GUI.Time = 0 -- don't touch
local PlayerData = {} -- don't touch
local showPro = false -- don't touch
local stealing = false -- don't touch
local peeking = false -- don't touch
local CurrentAction		= nil
local timer = false
local secsRemaining = nil
local savedDoor = nil
local doorTime = {}
peds = {}
local houseIn = nil
------------------------------------------------------
------------------------------------------------------
local useQalleCameraSystem = false --( https://github.com/qalle-fivem/esx-qalle-camerasystem )
local chancePoliceNoti = 50 -- the procent police get notified (only numbers like 30, 10, 40. You get it.)
local useBlip = false -- if u want blip
local useInteractSound = false -- if you wanna use InteractSound (when u lockpick the door)
------------------------------------------------------
------------------------------------------------------

------ l o c a l e s ------
local noCar = "No car nearby"
local text = "~r~lockpick~w~ door?" -- lockpick the door
local textUnlock = "~g~[E]~w~ Enter" -- enter the house
local insideText = "~g~[E]~w~ Exit" -- exit the door
local abortConfirm = "You have aborted the lockpicking"
local searchText = "~g~[E]~w~ Search" -- search the spot
local emptyMessage = "There is nothing here!" -- if you press E where it is empty
local emptyMessage3D = "~r~Empty" -- if the spot is empty
local closetText = "~g~[E]~w~ Peek into closet" -- text at closet
local abortLock = "~g~[E]~w~ To abort lockpicking"
local noLockpickText = "You don't have any lockpick!" -- if you don't have a lockpick and you try to do the burglary
local carUnlocked = "You have unlocked the car"
local youFound = "From the" -- when you steal something
local burglaryDetected = "A burglary has been detected at" -- text 1 cops gets sent
local sentPhoto = "We've sent you a photo of the criminal." -- if you use qalle's camerasystem this will be in the message too
local item = {'ring', 'goldNecklace', 'laptop', 'coke_pooch', 'weed_pooch', 'samsungS10', 'rolex', 'camera'}
local exitPos = {pos = {x = 0, y = 0, z = 0, h = 0 }}
local lastDoor = 0
local noiseXYZ = { x = 346.53 , y = -1003.44 , z = -99.2}
---------------------------


local PlayerData = {}

Citizen.CreateThread(function ()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(1)
  end
while ESX.GetPlayerData() == nil do
  Citizen.Wait(10)
end
PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)



RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('99kr-burglary:onUse')
AddEventHandler('99kr-burglary:onUse', function()
	local playerPed		= GetPlayerPed(-1)
  local coords		= GetEntityCoords(playerPed)
	if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then
		local vehicle = nil

		if IsPedInAnyVehicle(playerPed, false) then
			vehicle = GetVehiclePedIsIn(playerPed, false)
		else
			vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
		end

    if DoesEntityExist(vehicle) then
      lockpicking = false
      ---print(lockpicking)
      randi = math.random(1, 10)
      if randi == 1 then
      TriggerServerEvent('99kr-burglary:removeKit')
      end
			TaskStartScenarioInPlace(playerPed, "PROP_HUMAN_BUM_BIN", 0, true)
			  if useInteractSound then
			    TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 3.0, 'lockpick', 0.7)
			  end

			Citizen.CreateThread(function()
				ThreadID = GetIdOfThisThread()
				CurrentAction = 'lockpick'

				Citizen.Wait(22 * 1000)

        if CurrentAction ~= nil then
          procent(100)
					SetVehicleDoorsLocked(vehicle, 1)
					SetVehicleDoorsLockedForAllPlayers(vehicle, false)
					ClearPedTasksImmediately(playerPed)

					ESX.ShowNotification(carUnlocked)
				end
				
				CurrentAction = nil
				--TerminateThisThread()
			end)
		end

		Citizen.CreateThread(function()
			Citizen.Wait(0)

			if CurrentAction ~= nil then
				SetTextComponentFormat('STRING')
				AddTextComponentString(abortLock)
				DisplayHelpTextFromStringLabel(0, 0, 1, -1)

				if IsControlJustReleased(0, Keys["X"]) then
					TerminateThread(ThreadID)
					ESX.ShowNotification(abortConfirm)
					CurrentAction = nil
				end
			end

		end)
	end
end)




RegisterNetEvent('99kr-burglary:Lockpick')
AddEventHandler('99kr-burglary:Lockpick', function(xPlayer)
  lockpicking = true
  Citizen.Wait(100)
  lockpicking = false
end)

local burglaryPlaces = {
  
  ["Robban"] = {
    door = 1,
    locked = true,
    pos = { x = 1229.1, y = -725.47, z = 60.80, h = 89.98 }, -- door coords
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = { x = 1229.53, y = -724.81, z = 60.96, h = 277.96 }, -- The animation position
    doorTime = {}
    },
  ["Grove Street 1"] = {
    door = 2,
    locked = true,
    pos = { x = 126.73, y = -1930.20, z = 22.0, h = 207.79 },  -- door coords
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },  -- Inside the house coords
    animPos = { x = 126.73, y = -1930.00, z = 21.38, h = 207.79 }, -- The animation position
    doorTime = {}
  }, 
  ["Grove Street 2"] = {
    door = 3,
    locked = true,
    pos = { x = 85.58 , y = -1959.38 , z = 21.12, h = 220.54 },  -- door coords
    inside = { x = 346.52, y = -1013.19, z = -99.2, h = 357.81 },  -- Inside the house coords
    animPos = { x = 85.58 , y = -1959.38 , z = 21.12, h = 220.54 }, -- The animation position
    doorTime = {}
  },
  ["Robban1"] = {
    door = 4,
    locked = true,
    pos = {x = 1222.8, y = -697.01, z = 60.98, h = 288.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1222.8, y = -697.01, z = 60.98, h = 288.5}, -- The animation position
    doorTime = {}
    },
  ["Robban2"] = {
    door = 5,
    locked = true,
    pos = {x = 1207.1, y = -620.3, z = 66.65, h = 273.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1207.1, y = -620.3, z = 66.65, h = 273.5}, -- The animation position
    doorTime = {}
  },
  ["Robban3"] = {
    door = 6,
    locked = true,
    pos = {x = 1221.37, y = -669.12, z = 63.76, h = 196.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1221.37, y = -669.12, z = 63.76, h = 196.5}, -- The animation position
    doorTime = {}
  },
  ["Robban4"] = {
    door = 7,
    locked = true,
    pos = {x = 1203.59, y = -598.59, z = 68.41, h = 360.0}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1203.59, y = -598.59, z = 68.41, h = 360.0}, -- The animation position
    doorTime = {}
  },
  ["Robban5"] = {
    door = 8,
    locked = true,
    pos = {x = 1200.8, y = -575.8, z = 69.43, h = 318.0}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1200.8, y = -575.8, z = 69.43, h = 318.0}, -- The animation position
    doorTime = {}
  },
  ["Robban6"] = {
    door = 9,
    locked = true,
    pos = {x = 1204.46, y = -557.81, z = 69.75, h = 273.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 1204.46, y = -557.81, z = 69.75, h = 273.5}, -- The animation position
    doorTime = {}
  },
  ["bloods"] = {
    door = 10,
    locked = true,
    pos = {x = 16.62, y = -1443.79, z = 30.98, h = 333.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = 16.62, y = -1443.79, z = 30.98, h = 333.5}, -- The animation position
    doorTime = {}
  },
  ["bloods1"] = {
    door = 11,
    locked = true,
    pos = {x = -1.93, y = -1442.09, z = 31.07, h = 358.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = -1.93, y = -1442.09, z = 31.07, h = 358.5}, -- The animation position
    doorTime = {}
  },
  ["bloods2"] = {
    door = 12,
    locked = true,
    pos = {x = -32.28, y = -1446.38, z = 32.05, h = 265.5}, -- door coords -- {x = 1222.95, y = -696.97, z = 60.8, h = 288.5,
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, -- Inside coords
    animPos = {x = -32.28, y = -1446.38, z = 32.05, h = 265.5}, -- The animation position
    doorTime = {}
  },
  ["bloods3"] = {
    door = 13,
    locked = true,
    pos = {x = -45.52, y = -1445.42, z = 32.82, h = 270.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = -45.52, y = -1445.42, z = 32.82, h = 270.5}, 
    doorTime = {}
  },
  ["bloods4"] = {
    door = 14,
    locked = true,
    pos = {x = -64.58, y = -1449.61, z = 32.63, h = 101.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = -64.58, y = -1449.61, z = 32.63, h = 101.5}, 
    doorTime = {}
  },
  ["grove3"] = {
    door = 15,
    locked = true,
    pos = {x = 45.98, y = -1864.23, z = 23.46, h = 318.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 45.98, y = -1864.23, z = 23.46, h = 318.5}, 
  },
  ["grove4"] = {
    door = 16,
    locked = true,
    pos = {x = 30.01, y = -1854.72, z = 24.2, h = 210.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 30.01, y = -1854.72, z = 24.2, h = 210.5}, 
    doorTime = {}
  },
  ["grove5"] = {
    door = 17,
    locked = true,
    pos = {x = 21.29, y = -1844.8, z = 24.89, h = 233.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 21.29, y = -1844.8, z = 24.89, h = 233.5}, 
    doorTime = {}
  },
  ["grove6"] = {
    door = 18,
    locked = true,
    pos = {x = 118.48, y = -1921.0, z = 21.84, h = 234.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 118.48, y = -1921.0, z = 21.84, h = 234.5}, 
  },
  ["grove7"] = {
    door = 19,
    locked = true,
    pos = {x = 100.95, y = -1912.27, z = 21.64, h = 334.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 100.95, y = -1912.27, z = 21.64, h = 334.5}, 
    doorTime = {}
  },
  ["grove8"] = {
    door = 20,
    locked = true,
    pos = {x = 114.43, y = -1961.2, z = 21.6, h = 195.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 114.43, y = -1961.2, z = 21.6, h = 195.5}, 
    doorTime = {}
  },
  ["grove9"] = {
    door = 21,
    locked = true,
    pos = {x = 76.23, y = -1948.13, z = 21.43, h = 40.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 76.23, y = -1948.13, z = 21.43, h = 40.5}, 
    doorTime = {}
  },
  ["grove10"] = {
    door = 22,
    locked = true,
    pos = {x = 72.09, y = -1938.98, z = 21.63, h = 135.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 72.09, y = -1938.98, z = 21.63, h = 135.5}, 
    doorTime = {}
  },
  ["grove11"] = {
    door = 23,
    locked = true,
    pos = {x = 56.58, y = -1922.73, z = 22.23, h = 141.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 56.58, y = -1922.73, z = 22.23, h = 141.5}, 
    doorTime = {}
  },
  ["grove12"] = {
    door = 24,
    locked = true,
    pos = {x = 38.97, y = -1911.61, z = 22.37, h = 24.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 38.97, y = -1911.61, z = 22.37, h = 24.5}, 
    doorTime = {}
  },
  ["grove13"] = {
    door = 25,
    locked = true,
    pos = {x = 5.15, y = -1884.36, z = 23.8, h = 237.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 5.15, y = -1884.36, z = 23.8, h = 237.5}, 
    doorTime = {}
  },
  ["grove14"] = {
    door = 26,
    locked = true,
    pos = {x = -4.91, y = -1871.95, z = 24.42, h = 228.0}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = -4.91, y = -1871.95, z = 24.42, h = 228.0}, 
    doorTime = {}
  },
  ["grove15"] = {
    door = 27,
    locked = true,
    pos = {x = -20.9, y = -1858.78, z = 25.54, h = 235.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = -20.9, y = -1858.78, z = 25.54, h = 235.5}, 
    doorTime = {}
  },
  ["grove16"] = {
    door = 28,
    locked = true,
    pos = {x = -34.14, y = -1846.94, z = 26.34, h = 58.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = -34.14, y = -1846.94, z = 26.34, h = 58.5}, 
    doorTime = {}
  },
  ["grove17"] = {
    door = 29,
    locked = true,
    pos = {x = 216.42, y = -1717.34, z = 30.02, h = 134.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 216.42, y = -1717.34, z = 30.02, h = 134.5}, 
    doorTime = {}
  },
  ["grove18"] = {
    door = 30,
    locked = true,
    pos = {x = 222.62, y = -1702.51, z = 30.07, h = 33.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 222.62, y = -1702.51, z = 30.07, h = 33.5}, 
    doorTime = {}
  },
  ["grove19"] = {
    door = 31,
    locked = true,
    pos = {x = 240.67, y = -1687.76, z = 30.09, h = 42.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 240.67, y = -1687.76, z = 30.09, h = 42.5}, 
    doorTime = {}
  },
  ["grove20"] = {
    door = 31,
    locked = true,
    pos = {x = 54.35, y = -1873.02, z = 23.13, h = 307.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 54.35, y = -1873.02, z = 23.13, h = 307.5}, 
    doorTime = {}
  },
    ["grove21"] = {
    door = 32,
    locked = true,
    pos = {x = 252.91, y = -1670.85, z = 29.99, h = 308.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 252.91, y = -1670.85, z = 29.99, h = 308.5}, 
    doorTime = {}
  },
  ["grove22"] = {
    door = 33,
    locked = true,
    pos = {x = 282.06, y = -1694.77, z = 29.92, h = 226.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 282.06, y = -1694.77, z = 29.92, h = 226.5},
    doorTime = {}
  },
  ["grove23"] = {
    door = 34,
    locked = true,
    pos = {x = 269.67, y = -1712.88, z = 30.07, h = 321.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 269.67, y = -1712.88, z = 30.07, h = 321.5}, 
    doorTime = {}
  },
  ["grove24"] = {
    door = 35,
    locked = true,
    pos = {x = 269.16, y = -1728.69, z = 29.97, h = 122.5},
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 }, 
    animPos = {x = 269.16, y = -1728.69, z = 29.97, h = 122.5},
    doorTime = {}
  },
  ["grove25"] = {
    door = 36,
    locked = true,
    pos = {x = 250.12, y = -1730.76, z = 29.91, h = 223.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = 250.12, y = -1730.76, z = 29.91, h = 223.5}, 
    doorTime = {}
  },
    ["hills1"] = {
    door = 37,
    locked = true,
    pos = {x = -930.33, y = 19.55, z = 49.0, h = 36.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -930.33, y = 19.55, z = 49.0, h = 36.5}, 
    doorTime = {}
  },
  ["hills2"] = {
    door = 38,
    locked = true,
    pos = {x = -888.09, y = 43.0, z = 49.69, h = 33.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -888.09, y = 43.0, z = 49.69, h = 33.5}, 
    doorTime = {}
  },
  ["hills3"] = {
    door = 39,
    locked = true,
    pos = {x = -842.22, y = -25.12, z = 40.8, h = 90.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -842.22, y = -25.12, z = 40.8, h = 90.5}, 
    doorTime = {}
  },
  ["hills4"] = {
    door = 40,
    locked = true,
    pos = {x = -788.28, y = -6.79, z = 41.33, h = 300.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -788.28, y = -6.79, z = 41.33, h = 300.5}, 
    doorTime = {}
  },
  ["hills5"] = {
    door = 41,
    locked = true,
    pos = {x = -896.78, y = -5.17, z = 44.23, h = 126.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -896.78, y = -5.17, z = 44.23, h = 126.5}, 
    doorTime = {}
  },
  ["hill6"] = {
    door = 42,
    locked = true,
    pos = {x = -888.23, y = 42.69, z = 49.64, h = 61.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -888.23, y = 42.69, z = 49.64, h = 61.5}, 
    doorTime = {}
  },
  ["hill7"] = {
    door = 43,
    locked = true,
    pos = {x = -930.28, y = 19.51, z = 49.12, h = 36.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -930.28, y = 19.51, z = 49.12, h = 36.5}, 
    doorTime = {}
  },
  ["hill8"] = {
    door = 44,
    locked = true,
    pos = {x = -1038.04, y = 222.12, z = 65.01, h = 279.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1038.04, y = 222.12, z = 65.01, h = 279.5}, 
    doorTime = {}
  },
  ["hill9"] = {
    door = 45,
    locked = true,
    pos = {x = -1038.79, y = 311.93, z = 67.98, h = 210.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1038.79, y = 311.93, z = 67.98, h = 210.5}, 
    doorTime = {}
  },
  ["hill10"] = {
    door = 46,
    locked = true,
    pos = {x = -1052.53, y = 375.15, z = 70.23, h = 7.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1052.53, y = 375.15, z = 70.23, h = 7.5}, 
    doorTime = {}
  },
  ["hill11"] = {
    door = 47,
    locked = true,
    pos = {x = -1094.88, y = 427.56, z = 76.37, h = 83.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1094.88, y = 427.56, z = 76.37, h = 83.5}, 
    doorTime = {}
  },
  ["12"] = {
    door = 48,
    locked = true,
    pos = {x = -1052.26, y = 432.53, z = 77.71, h = 18.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1052.26, y = 432.53, z = 77.71, h = 18.5}, 
    doorTime = {}
  },
  ["13"] = {
    door = 49,
    locked = true,
    pos = {x = -1087.36, y = 479.27, z = 82.05, h = 233.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1087.36, y = 479.27, z = 82.05, h = 233.5}, 
    doorTime = {}
  },
  ["14"] = {
    door = 50,
    locked = true,
    pos = {x = -1122.47, y = 486.32, z = 82.79, h = 344.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1122.47, y = 486.32, z = 82.79, h = 344.5}, 
    doorTime = {}
  },
  ["15"] = {
    door = 51,
    locked = true,
    pos = {x = -1158.93, y = 481.83, z = 86.64, h = 9.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1158.93, y = 481.83, z = 86.64, h = 9.5}, 
    doorTime = {}
  },
  ["16"] = {
    door = 52,
    locked = true,
    pos = {x = -1174.4, y = 440.25, z = 87.4, h = 265.0}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1174.4, y = 440.25, z = 87.4, h = 265.0}, 
    doorTime = {}
  },
  ["17"] = {
    door = 53,
    locked = true,
    pos = {x = -1215.98, y = 457.86, z = 92.43, h = 181.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1215.98, y = 457.86, z = 92.43, h = 181.5}, 
    doorTime = {}
  },
  ["18"] = {
    door = 54,
    locked = true,
    pos = {x = -1277.88, y = 497.15, z = 98.42, h = 89.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1277.88, y = 497.15, z = 98.42, h = 89.5}, 
    doorTime = {}
  },
  ["19"] = {
    door = 55,
    locked = true,
    pos = {x = -1193.09, y = 564.02, z = 100.79, h = 11.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1193.09, y = 564.02, z = 100.79, h = 11.5}, 
    doorTime = {}
  },
  ["20"] = {
    door = 56,
    locked = true,
    pos = {x = -1166.93, y = 568.78, z = 102.34, h = 29.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -1166.93, y = 568.78, z = 102.34, h = 29.5}, 
    doorTime = {}
  },
  ["21"] = {
    door = 57,
    locked = true,
    pos = {x = -360.24, y = 6260.61, z = 31.9, h = 131.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -360.24, y = 6260.61, z = 31.9, h = 131.5}, 
    doorTime = {}
  },
  ["22"] = {
    door = 58,
    locked = true,
    pos = {x = -332.52, y = 6302.07, z = 33.09, h = 247.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -332.52, y = 6302.07, z = 33.09, h = 247.5}, 
    doorTime = {}
  },
  ["23"] = {
    door = 59,
    locked = true,
    pos = {x = -364.16, y = 6337.56, z = 29.84, h = 303.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -364.16, y = 6337.56, z = 29.84, h = 303.5}, 
    doorTime = {}
  },
  ["24"] = {
    door = 60,
    locked = true,
    pos = {x = -407.56, y = 6313.99, z = 28.94, h = 10.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -407.56, y = 6313.99, z = 28.94, h = 10.5}, 
    doorTime = {}
  },
  ["25"] = {
    door = 61,
    locked = true,
    pos = {x = -3190.99, y = 1297.74, z = 19.06, h = 64.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3190.99, y = 1297.74, z = 19.06, h = 64.5}, 
    doorTime = {}
  },
  ["26"] = {
    door = 62,
    locked = true,
    pos = {x = -3196.46, y = 1280.62, z = 12.66, h = 73.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3196.46, y = 1280.62, z = 12.66, h = 73.5}, 
    doorTime = {}
  },
  ["27"] = {
    door = 63,
    locked = true,
    pos = {x = -3200.32, y = 1232.44, z = 10.04, h = 173.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3200.32, y = 1232.44, z = 10.04, h = 173.5}, 
    doorTime = {}
  },
  ["28"] = {
    door = 64,
    locked = true,
    pos = {x = -3193.52, y = 1208.5, z = 9.42, h = 175.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3193.52, y = 1208.5, z = 9.42, h = 175.5}, 
    doorTime = {}
  },
  ["29"] = {
    door = 65,
    locked = true,
    pos = {x = -3205.81, y = 1185.67, z = 9.66, h = 211.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3205.81, y = 1185.67, z = 9.66, h = 211.5}, 
    doorTime = {}
  },
  ["30"] = {
    door = 66,
    locked = true,
    pos = {x = -3200.52, y = 1165.15, z = 9.65, h = 76.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3200.52, y = 1165.15, z = 9.65, h = 76.5}, 
    doorTime = {}
  },
  ["31"] = {
    door = 67,
    locked = true,
    pos = {x = -3220.04, y = 1138.42, z = 9.89, h = 337.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3220.04, y = 1138.42, z = 9.89, h = 337.5}, 
    doorTime = {}
  },
    ["32"] = {
    door = 67,
    locked = true,
    pos = {x = -3210.13, y = 1144.55, z = 9.89, h = 167.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3210.13, y = 1144.55, z = 9.89, h = 167.5}, 
    doorTime = {}
  },
  ["33"] = {
    door = 68,
    locked = true,
    pos = {x = -3224.97, y = 1112.59, z = 10.8, h = 186.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3224.97, y = 1112.59, z = 10.8, h = 186.5}, 
    doorTime = {}
  },
  ["34"] = {
    door = 69,
    locked = true,
    pos = {x = -3228.66, y = 1092.7, z = 10.77, h = 72.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3228.66, y = 1092.7, z = 10.77, h = 72.5}, 
    doorTime = {}
  },
  ["35"] = {
    door = 70,
    locked = true,
    pos = {x = -3232.94, y = 1067.8, z = 11.03, h = 73.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3232.94, y = 1067.8, z = 11.03, h = 73.5}, 
    doorTime = {}
  },
  ["36"] = {
    door = 71,
    locked = true,
    pos = {x = -3254.37, y = 1063.65, z = 11.14, h = 182.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3254.37, y = 1063.65, z = 11.14, h = 182.5}, 
    doorTime = {}
  },
  ["37"] = {
    door = 72,
    locked = true,
    pos = {x = -3248.52, y = 1042.14, z = 11.75, h = 175.5}, 
    inside = { x = 346.52 , y = -1013.19 , z = -99.2, h = 357.81 },
    animPos = {x = -3248.52, y = 1042.14, z = 11.75, h = 175.5}, 
    doorTime = {}
  },

}

residents = {
	{
		coord = vec3(349.8, -996.141, -98.7399),
		rotation = 90.0,
		animation = { dict = "amb@lo_res_idles@", anim = "lying_face_up_lo_res_base" }, -- sleeping animation
		model = "a_f_y_hipster_01",
		aggressive = true -- if they should attack after waking up
	}
}




local burglaryInside = {
[" kitchen table you found "] = { x = 342.23, y = -1003.29, z = -99.0,  amount = 0},
[" tv draw you found "] = { x = 338.14, y = -997.69,  z = -99.2,  amount = 0},
[" bedroom draw you found "] = { x = 350.91, y = -999.26,  z = -99.2,  amount = 0},
[" bed side table you found "] = { x = 349.19, y = -994.83,  z = -99.2,  amount = 0},
[" book shelf you found "] = { x = 345.3,  y = -995.76,  z = -99.2,  amount = 0},
[" hallway table you found "] = { x = 346.14, y = -1001.55, z = -99.2,  amount = 0},
[" bathroom draw you found "] = { x = 347.23, y = -994.09,  z = -99.2,  amount = 0},
[" dinning table you found "] = { x = 339.23, y = -1003.35, z = -99.2,  amount = 0},
[" wardrobe you found "] = { x = 351.24, y = -993.53,  z = -99.2,  amount = 0}

}

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(5)
    for k,v in pairs(burglaryPlaces) do
      local playerPed = PlayerPedId()
      local house = k
      local coords = GetEntityCoords(playerPed)
      local dist   = GetDistanceBetweenCoords(v.pos.x, v.pos.y, v.pos.z, coords.x, coords.y, coords.z, false)
    if GetClockHours() > 23  or GetClockHours() <= 22 then
      if dist <= 1.2 and v.locked == true then
          DrawText3D(v.pos.x, v.pos.y, v.pos.z, text, 0.4)                  
          if lockpicking == true then
            RemoveResidents()
            savedDoor = v.door
            houseIn = house
            v.doorTime = GetGameTimer() + 600 * 1000
            confMenu(house)
            for k, v in pairs(burglaryInside) do
              if v.amount < 1 then
              v.amount = v.amount + 1
              lockpicking = false
              end
            end
          end  
      else
        if dist <= 1.2 and timer == true then
         local secsRemaining = math.ceil((v.doorTime - GetGameTimer()) / 1000)
          secsRemaining = secsRemaining - 1
          if secsRemaining > 0 then
                DrawText3D(v.pos.x, v.pos.y, v.pos.z,'Please wait ~r~'..secsRemaining..'~w~ until you can Break in', 0.4)
          else
            timer = false
            v.locked = true 
            doorTime = {}      
          end
          
        end
      end
    else 
      if dist <= 1.2 then
        breakTime = 23 - GetClockHours() 
      DrawText3D(v.pos.x, v.pos.y, v.pos.z, 'you can break into the house in ~r~' ..breakTime.. ' ~w~hours', 0.4) 
      end
    end
    end
  end
end)

Citizen.CreateThread(function()
  while stealing == false do
    Citizen.Wait(5)
    for k, v in pairs(burglaryInside) do
      local playerPed = PlayerPedId()
      local coords = GetEntityCoords(playerPed)
      local dist = GetDistanceBetweenCoords(v.x, v.y, v.z, coords.x, coords.y, coords.z, false)
      if dist <= 1.2 and v.amount > 0 then
        DrawText3D(v.x, v.y, v.z, searchText, 0.4)
        if dist <= 0.5 and IsControlJustPressed(0, Keys["E"]) then
          steal(k)
        end
      elseif v.amount < 1 and dist <= 1.2 then
        DrawText3D(v.x, v.y, v.z, emptyMessage3D, 0.4)
        if IsControlJustPressed(0, Keys["E"]) and dist <= 0.5 then
          ESX.ShowNotification(emptyMessage)
        end
      end
    end
  end
end)


Citizen.CreateThread(function()
  while true do
    Citizen.Wait(5)
    for k, v in pairs(burglaryPlaces) do
      local playerPed = PlayerPedId()
      local coords = GetEntityCoords(playerPed)
      local house = k
      if GetDistanceBetweenCoords(noiseXYZ.x, noiseXYZ.y, noiseXYZ.z, coords.x, coords.y, coords.z, false) <= 14.0 then
        DrawNoiseBar(GetPlayerCurrentStealthNoise(PlayerId()), 3)
      end
      if GetDistanceBetweenCoords(v.inside.x, v.inside.y, v.inside.z, coords.x, coords.y, coords.z, false) <= 3.0 then
        DrawText3D(v.inside.x, v.inside.y, v.inside.z, insideText, 0.4)
        if GetDistanceBetweenCoords(v.inside.x, v.inside.y, v.inside.z, coords.x, coords.y, coords.z, false) <= 1.2 and IsControlJustPressed(0, Keys["E"]) then
          RemoveResidents()
          fade()
          teleport(exitPos)
          lastDoor = 0
          timer = true
          
        end
      end
    end
  end
end)


Citizen.CreateThread(function()
	while true do
    Citizen.Wait(6)
    if showPro == true then
      local playerPed = PlayerPedId()
		  local coords = GetEntityCoords(playerPed)
      DrawText3D(coords.x, coords.y, coords.z, TimeLeft .. '~g~%', 0.4)
    end
	end
end)

function confMenu(house)
  Citizen.Wait(6)
  RemoveResidents()
  local v = GetHouseValues(house, burglaryPlaces)
  exitPos = {pos ={x = v.pos.x, y = v.pos.y, z = v.pos.z, h = v.pos.h }}
  Citizen.CreateThread(function()
    local inventory = ESX.GetPlayerData().inventory
    local LockpickAmount = nil
      for i=1, #inventory, 1 do                          
        if inventory[i].name == 'lockpick' then
          LockpickAmount = inventory[i].count
        end
      end
        if LockpickAmount > 0 then
          SpawnResidents(home)
          HouseBreak(house)
          v.locked = false
          Citizen.Wait(math.random(15000,30000))
          local random = math.random(0, 100)
          if random <= chancePoliceNoti then 
            TriggerServerEvent('esx_addons_gcphone:startCall', 'police', burglaryDetected .. '\n ' .. house, { x = exitPos.pos.x, y = exitPos.pos.y, z = exitPos.pos.z })
          end
        else 
          ESX.ShowNotification(noLockpickText)
        end
	end)
end
                        
function steal(k)
  local goods = item[math.random(#item)] 
  local values = GetHouseValues(k, burglaryInside)
  local playerPed = PlayerPedId()
  stealing = true
  FreezeEntityPosition(playerPed, true)
  TaskStartScenarioInPlace(playerPed, "PROP_HUMAN_BUM_BIN", 0, true)
  Citizen.Wait(2000)
  procent(50)
  TriggerServerEvent('99kr-burglary:Add', goods, 1)
  ESX.ShowNotification(youFound .. k ..' '.. goods)
  values.amount = values.amount - 1
  ClearPedTasks(playerPed)
  FreezeEntityPosition(playerPed, false)
  stealing = false
end

function HouseBreak(house)
  local v = GetHouseValues(house, burglaryPlaces)
  local playerPed = PlayerPedId()
  fade()
  FreezeEntityPosition(playerPed, true)
  SetEntityCoords(playerPed, v.animPos.x, v.animPos.y, v.animPos.z - 0.98)
  SetEntityHeading(playerPed, v.animPos.h)
  loaddict("mini@safe_cracking")
  TaskPlayAnim(playerPed, "mini@safe_cracking", "idle_base", 3.5, - 8, - 1, 2, 0, 0, 0, 0, 0)
  if useInteractSound then
    TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 3.0, 'lockpick', 0.7)
  end
  procent(70)
  rand = math.random(1, 10)
  if rand == 1 then
    TriggerServerEvent('99kr-burglary:Remove', 'lockpick', 1)
  end  
  fade()
  ClearPedTasks(playerPed)
  FreezeEntityPosition(playerPed, false)
  SetCoords(playerPed, v.inside.x, v.inside.y, v.inside.z - 0.98)
  SetEntityHeading(playerPed, v.inside.h)
end 

function ShowSubtitle(text)
  BeginTextCommandPrint("STRING")
  AddTextComponentSubstringPlayerName(text)
  EndTextCommandPrint(3500, 1)
end

function SetCoords(playerPed, x, y, z)
  SetEntityCoords(playerPed, x, y, z)
  Citizen.Wait(100)
  SetEntityCoords(playerPed, x, y, z)
end

function DrawTimerBar(title, text, barIndex)
	local width = 0.13
	local hTextMargin = 0.003
	local rectHeight = 0.038
	local textMargin = 0.008
	
	local rectX = GetSafeZoneSize() - width + width / 2
	local rectY = GetSafeZoneSize() - rectHeight + rectHeight / 2 - (barIndex - 1) * (rectHeight + 0.005)
	
	DrawSprite("timerbars", "all_black_bg", rectX, rectY, width, 0.038, 0, 0, 0, 0, 128)
	
	DrawText2d(title, GetSafeZoneSize() - width + hTextMargin, rectY - textMargin, 0.32)
	DrawText2d(string.upper(text), GetSafeZoneSize() - hTextMargin, rectY - 0.0175, 0.5, true, width / 2)
end

function DrawNoiseBar(noise, barIndex)
	DrawTimerBar("NOISE", math.floor(noise), barIndex)
end

function DrawText2d(text, x, y, scale, right, width)
	SetTextFont(0)
	SetTextScale(scale, scale)
	SetTextColour(254, 254, 254, 255)

	if right then
		SetTextWrap(x - width, x)
		SetTextRightJustify(true)
	end
	
	BeginTextCommandDisplayText("STRING")	
	AddTextComponentSubstringPlayerName(text)
	EndTextCommandDisplayText(x, y)
end

function callCops(house)
    if  savedDoor ~= lastDoor then
    TriggerServerEvent('esx_addons_gcphone:startCall', 'police', burglaryDetected .. '\n ' .. houseIn, { x = exitPos.pos.x, y = exitPos.pos.y, z = exitPos.pos.z })
    lastDoor = savedDoor
    end
end

function fade()
  DoScreenFadeOut(1000)
  Citizen.Wait(1000)
  DoScreenFadeIn(1000)
end

function loaddict(dict)
  while not HasAnimDictLoaded(dict) do
    RequestAnimDict(dict)
    Wait(10)
  end
end

Citizen.CreateThread(function(house)
	while true do
    Citizen.Wait(6)
    if GetPlayerCurrentStealthNoise(PlayerId()) > 5 then
    if CanPedHearPlayer(PlayerId(), peds[1]) then
      callCops(house)
      ClearPedTasks(peds[1])
      Citizen.Wait(5)
      PlayPain(peds[1], 7, 0)
      if HasPedGotWeapon(peds[1], GetHashKey("WEAPON_PISTOL"), false) then
        SetCurrentPedWeapon(peds[1], GetHashKey("WEAPON_PISTOL"), true)
        Citizen.Wait(5)
        TaskShootAtEntity(peds[1], PlayerPedId(), -1, 2685983626)
        Citizen.Wait(7000)
      end
    end
    end
  end
end)

function SpawnResidents(home)
 
		RequestModel("a_f_y_hipster_01")
		while not HasModelLoaded("a_f_y_hipster_01") do 
		  Wait(0)
    end
    for _,resident in pairs(residents) do
		 ped = CreatePed(4, resident.model, resident.coord, resident.rotation, false, false)
			table.insert(peds, ped)
			-- animation
      RequestAnimDict(resident.animation.dict)
      while not HasAnimDictLoaded(resident.animation.dict) do 
        Wait(0) 
      end
      
      TaskPlayAnimAdvanced(ped, resident.animation.dict, resident.animation.anim, resident.coord, 0.0, 0.0, resident.rotation, 8.0, 1.0, -1, 1, 1.0, true, true)
      SetFacialIdleAnimOverride(ped, "mood_sleeping_1", 0)

      SetPedHearingRange(ped, 3.0)
			SetPedSeeingRange(ped, 3.0)
      SetPedAlertness(ped, 1)

      if resident.aggressive then
        GiveWeaponToPed(ped, GetHashKey("WEAPON_PISTOL"), 255, true, false)
      end

      
  end
      
  
end

function RemoveResidents()
	for _,ped in pairs(peds) do
		SetPedAsNoLongerNeeded(ped)
    DeletePed(ped)
   
	end
	
  peds = {}
end


function DrawText3D(x, y, z, text, scale)
  local onScreen, _x, _y = World3dToScreen2d(x, y, z)
  local pX, pY, pZ = table.unpack(GetGameplayCamCoords())
  SetTextScale(scale, scale)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextEntry("STRING")
  SetTextCentre(1)
  SetTextColour(255, 255, 255, 255)
  SetTextOutline()
  AddTextComponentString(text)
  DrawText(_x, _y)
  local factor = (string.len(text)) / 270
  DrawRect(_x, _y + 0.015, 0.005 + factor, 0.03, 31, 31, 31, 155)
end

function procent(time)
  showPro = true
  TimeLeft = 0
  repeat
  TimeLeft = TimeLeft + 1 -- thank you (github.com/Loffes)
  Citizen.Wait(time)
  until(TimeLeft == 100)
  showPro = false
end

function teleport(confMenu)
  local values = GetHouseValues(house, burglaryPlaces)
  local playerPed = PlayerPedId()
  SetCoords(playerPed, confMenu.pos.x, confMenu.pos.y, confMenu.pos.z - 0.98)
  SetEntityHeading(playerPed, confMenu.pos.h)
  DoingBreak = false
end

function GetHouseValues(house, pair)
  for k, v in pairs(pair) do
    if k == house then
      return v
    end
  end
end

if useBlip then
  Citizen.CreateThread(function()
    for k, v in pairs(burglaryPlaces) do
       local blip = AddBlipForCoord(v.pos.x, v.pos.y, v.pos.z)
       SetBlipSprite (blip, 40)
       SetBlipDisplay(blip, 4)
       SetBlipScale (blip, 0.8)
       SetBlipColour (blip, 39)
       SetBlipAsShortRange(blip, true)
       BeginTextCommandSetBlipName("STRING")
       AddTextComponentString('Burglary')
       EndTextCommandSetBlipName(blip)
    end
  end)
end

RegisterNetEvent('99kr-burglary:Sound')
AddEventHandler('99kr-burglary:Sound', function(sound1, sound2)
PlaySoundFrontend(-1, sound1, sound2)
end)

--------------  Pawn Shop ---------------------------
function hintToDisplay(text)
	SetTextComponentFormat("STRING")
	AddTextComponentString(text)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

local blips = {
  {title="Pawnshop", colour=4, id=133, x = 412.31, y = 314.11, z = 103.02}
}

Citizen.CreateThread(function()
  for _, info in pairs(blips) do
    info.blip = AddBlipForCoord(info.x, info.y, info.z)
    SetBlipSprite(info.blip, info.id)
    SetBlipDisplay(info.blip, 4)
    SetBlipScale(info.blip, 1.0)
    SetBlipColour(info.blip, info.colour)
    SetBlipAsShortRange(info.blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(info.title)
    EndTextCommandSetBlipName(info.blip)
  end
end)

local gym = {
  {x = 412.31, y = 314.11, z = 103.02}
}

Citizen.CreateThread(function()
  while true do
      Citizen.Wait(0)
      for k in pairs(gym) do
          DrawMarker(21, gym[k].x, gym[k].y, gym[k].z, 0, 0, 0, 0, 0, 0, 0.301, 0.301, 0.3001, 0, 153, 255, 255, 0, 0, 0, 0)
      end
  end
end)

Citizen.CreateThread(function()
  while true do
      Citizen.Wait(0)
      for k in pairs(gym) do
        local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
        local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, gym[k].x, gym[k].y, gym[k].z)
        if dist <= 0.5 then
          DrawText3D(plyCoords.x, plyCoords.y, plyCoords.z, "~w~Press ~r~[H] ~w~ to use pawn shop!", 0.4)
          if IsControlJustPressed(0, Keys['H'])then
            OpenSellMenu()
          end
        end		
      end
  end
end)

function OpenSellMenu()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
      'default', GetCurrentResourceName(), 'pawn_sell_menu',
      {
          title    = 'Do you have any of the following you want to sell?',
          elements = {
              {label = 'Ring', value = 'ring'},
              {label = 'Rolex', value = 'rolex'},
              {label = 'Camera', value = 'camera'},
              {label = 'Gold Necklace', value = 'goldNecklace'},
              {label = 'Laptop', value = 'laptop'},
              {label = 'Samsung S10', value = 'samsungS10'},
          }
      },
      function(data, menu)
          if data.current.value == 'ring' then
              TriggerServerEvent('99kr-burglary:sellring')
          elseif data.current.value == 'rolex' then
              TriggerServerEvent('99kr-burglary:sellrolex')
          elseif data.current.value == 'camera' then
              TriggerServerEvent('99kr-burglary:sellcamera')
          elseif data.current.value == 'goldNecklace' then
              TriggerServerEvent('99kr-burglary:sellgoldNecklace')
          elseif data.current.value == 'laptop' then
              TriggerServerEvent('99kr-burglary:selllaptop')
          elseif data.current.value == 'samsungS10' then
              TriggerServerEvent('99kr-burglary:sellsamsungS10')
          end
      end,
      function(data, menu)
          menu.close()
      end
  )
end