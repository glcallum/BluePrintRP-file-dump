Locales['en'] = {
  ['male'] = 'male',
  ['female'] = 'female',
  ['carjack'] = '~r~Carjacking in progress: a ~r~%s~s~ ~r~was spotted! ~y~PLATE:~o~%s~s~ at ~y~%s~s~',
  ['combat'] = '~r~Fight in progress: a ~r~%s~s~ ~r~has been spotted fighting at ~y~%s~s~',
  ['gunshot'] = '~r~Shootout in progress: a ~r~%s~s~ ~r~has been spotted firing a weapon at ~y~%s~s~',
  ['hacking'] = '~r~Hacking in progress: a ~r~%s~s~ ~r~has been spotted hacking a door at ~y~%s~s~',
  ['drugs'] = '~r~Drugs in progress: a person has been spotted selling drugs at ~y~%s~s~',
}