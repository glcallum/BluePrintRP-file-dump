Locales['en'] = {
	['cloakroom']				= 'cloakroom',
	['job_wear']				= 'workwear',
	['citizen_wear']			= 'civilian clothes',
	['vehiclespawner']			= 'choice of van', 
	['already_have_van']		= 'we have allready provided a van!', 
	['delivery']				= 'press ~INPUT_PICKUP~ to deliver.',
	['not_your_van']			= 'it is not the van that you have provided !',
	['not_your_van2']			= 'you must be in the van that you were provided with !',
	['need_it']					= 'yeah, but we need it !',
	['ok_work']					= 'ok, at work then !',
	['scared_me']				= 'ok, you scared me there !',
	['resume_delivery']			= 'ok, resume your delivery then !',
	['not_delivery']			= 'no delivery no Cash',
	['pay_repair']				= 'on the other hand you pay the repairs !',
	['repair_minus']			= 'van repairs : -',
	['shipments_plus']			= 'shipments : +',
	['van_state']				= 'no money dude, seen the state fo the van !',
	['no_delivery_no_van']	= 'no delivery, no van! Its a joke?',
	['van_price']				= 'van price : -',
	['meet_ls']					= 'go to the delivery point at Los Santos',
	['meet_bc']					= 'go to the delivery point at Blaine County',
	['meet_del']				= 'go to the delivery point',
	['return_depot']			= 'return to the depot.',
	['blip_job']				= 'walker Logistics',
	['blip_delivery']			= 'walker Logistics : Delivery',
	['blip_goal']				= 'walker Logistics : Delivery point',
	['blip_depot']				= 'walker Logistics : depot',
	['cancel_mission']			= 'press ~INPUT_PICKUP~ to cancel the mission',
}