Config = {}

Config.StatusMax      = 1000000
Config.TickTime       = 1000
Config.UpdateInterval = 10000