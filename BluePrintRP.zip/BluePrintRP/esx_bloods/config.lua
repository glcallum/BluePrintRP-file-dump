Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = {x = 1.5, y = 1.5, z = 1.5}
Config.MarkerColor                = {r = 255, g = 50, b = 200 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true
Config.MaxInService               = -1
Config.Locale                     = 'en'
Config.BloodsStations = {

  Bloods = {

    Blip = {
      Pos   = {x = -14.25, y = -1441.25, z = 31.19},
      Sprite  = 84,
      Display = 4,
      Scale   = 0.7,
      Colour  = 1,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_COMBATPISTOL',     price = 300 },
      { name = 'WEAPON_ASSAULTSMG',       price = 1500 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 1500 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 1000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 100000 },
      { name = 'WEAPON_APPISTOL',         price = 2000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 1500 },
      { name = 'WEAPON_SPECIALCARBINE',   price = 6000 },
      { name = 'WEAPON_HEAVYSNIPER',      price = 120000 },
      { name = 'WEAPON_REVOLVER',         price = 1000 },
      { name = 'WEAPON_MICROSMG',        price = 1500 },
      { name = 'WEAPON_SWITCHBLADE',      price = 70 },
      --{ name = 'WEAPON_PISTOL_MK2',      price = 15000 },
      --{ name = 'WEAPON_SMG_MK2',         price = 15000 },
      --{ name = 'WEAPON_COMBATMG_MK2',    price = 15000 },
      --{ name = 'WEAPON_ASSAULTRIFLE_MK2', price = 15000 },
      --{ name = 'WEAPON_CARBINERIFLE_MK2', price = 15000 },
      --{ name = 'WEAPON_HEAVYSNIPER_MK2', price = 15000 },
      --{ name = 'WEAPON_REVOLVER_MK2', price = 15000 },
      --{ name = 'WEAPON_SPECIALCARBINE_MK2', price = 15000 },
      --{ name = 'WEAPON_PUMPSHOTGUN_MK2', price = 15000 },
      --{ name = 'WEAPON_MARKSMANRIFLE_MK2', price = 15000 },
    },


	  AuthorizedVehicles = {
      { name = 'cls2015',  label = 'Mercedes CLS 63' },
      { name = 'rrphantom',  label = 'Rolls-Royce Phantom' },
      { name = 'btype',      label = 'Roosevelt' },
      { name = 'g65amg',   label = 'Mercedes G wagon' },
      { name = 'benson3',      label = 'Big transport (sprinter)' },
      { name = 'cayenne',   label = 'Porsche cayenne' },
      { name =  'caddyvw',   label = 'Small transport (caddy)' },
      { name = 'gmcs',       label = 'GMC Sierra 1500 (pickup)' },
      { name = 'xls2',       label = 'Armoured car' },
      { name = 'hfc250',       label = 'Dirtbike' },
      { name = 'bmws',       label = 'Sportbike' },
      { name =  'rs318',   label = 'Audi Rs3' },
      { name = 'a45amg',       label = 'Merc A45amg' },
      { name = 'blazer3',       label = 'Raptor 550cc' },
      { name = 'ytmax',       label = 'yamaha t-max' },
      { name = 'hcbr17',       label = 'Honda CBR' },
      { name = 'SVR14',       label = 'Range Rover' },
      { name = 'mk7',       label = 'Vw Golf Mk7' },
      { name = '450crf',       label = 'Honda super moto' },
      { name = 'golf7r',       label = 'Golf R' },
      { name = 'm6f13',       label = 'BMW M6' },
      { name = 'ss750',      label = 'SS750'},
	  },

   Cloakrooms = {
      { x = -18.43, y = -1438.56, z = 30.10},
    },

    Armories = {
      { x = -16.26, y = -1430.32, z = 30.10 },
      { x = 2454.55, y = 4978.11, z = 50.72 },
    },

    Vehicles = {
      {
        Spawner    = { x = 2485.21, y = 4953.05, z = 43.83 },
        SpawnPoint = { x = 2480.60, y = 4953.30, z = 46.01 },
        Spawner    = { x = -21.73, y = -1427.56, z = 29.65 },
        SpawnPoint = { x = -24.77, y = -1437.97, z = 31.65 },
        Heading    = 180.0,
      },

    },
  
  Helicopters = {
      {
        Spawner    = { x = 0, y = 0, z = 172.627 },
        SpawnPoint = { x = 0, y = 0, z = 176.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 2488.34, y = 4961.23, z = 44.20 },
      { x = -25.32, y = -1427.41, z = 29.75 },
    },

    BossActions = {
      { x = -10.61, y = -1433.46, z = 30.11 },
      { x = 2459.36, y = 4989.36, z = 46.81 },

    },

  },

}