Config               = {}
Config.usecommand    = true
Config.usekeybinding = false
Config.jobname      = 'police'

Config.modifierkey = 21 -- Left Shift
Config.code1key = 96 -- Numpad +
Config.code2key = 97 -- Numpad -
Config.code3key = 82 --  ,
Config.code99key = 81 --  .
