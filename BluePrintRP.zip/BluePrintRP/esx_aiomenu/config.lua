Config = {
	versionChecker = true
}

_VERSION 						= 3.0