Config = {
    Camera = true,
    LoseConnectionDistance = 100.0
}